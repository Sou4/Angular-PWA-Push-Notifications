export const environment = {
  production: true,
  buildName: 'Production',
  // apiEndPoint: 'http://192.168.43.145:7070',
  // authEndPoint: 'http://192.168.43.145:7070/oauth/token',
  // apiSecuredEndPoint: 'http://192.168.43.145:7070/secured',
  apiEndPoint: 'http://localhost:7070',
  authEndPoint: 'http://localhost:7070/oauth/token',
  apiSecuredEndPoint: 'http://localhost:7070/secured',
};
