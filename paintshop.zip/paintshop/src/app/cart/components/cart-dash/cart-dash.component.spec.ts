import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CartDashComponent } from './cart-dash.component';

describe('CartDashComponent', () => {
  let component: CartDashComponent;
  let fixture: ComponentFixture<CartDashComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CartDashComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CartDashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
