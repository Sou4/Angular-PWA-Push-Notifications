import { Component, OnInit } from '@angular/core';
import { CartService } from '../../../shared/services/cart.service';
import { Cart } from '../../../shared/models/cart';
import { AuthService } from '../../../shared/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart-dash',
  templateUrl: './cart-dash.component.html',
  styleUrls: ['./cart-dash.component.css']
})
export class CartDashComponent implements OnInit {

  cartList: Cart[] = [];
  totalAmount = 0;
  totalMrp = 0;
  totalItems = 0;

  constructor(private _cartServ: CartService, private _authServ: AuthService,
              private router: Router) { }

  ngOnInit() {

    this._authServ.loggedUserNameObsv
      .subscribe(res => {
        if (res === '') {
          // Not Logged In
          this.cartList = this._cartServ.getOfflineCartData();
          this.calculateTotalAmount();
        } else {
          // Logged In
          this._cartServ.getCartDataByUserId(this._authServ.getUserId())
          .subscribe(cartData => {
            this.cartList = cartData;
            this.calculateTotalAmount();
          });
        }
      });
  }

  calculateTotalAmount() {
    this.totalAmount = 0;
    this.totalMrp = 0;
    this.totalItems = 0;
    this.cartList.forEach(item => {
      this.totalAmount += (item.price * parseFloat(item.selectedPack) * item.qty);
      this.totalMrp += (item.mrp * parseFloat(item.selectedPack) * item.qty);
      this.totalItems += 1;
    });
  }

  palceOrder() {
    this._cartServ.cartData.next(this.cartList);
    this.router.navigate(['/order/placeOrder']);
  }
}
