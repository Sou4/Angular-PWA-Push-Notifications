import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CartService } from '../../../shared/services/cart.service';
import { Cart } from '../../../shared/models/cart';
import { _ } from 'underscore';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart-list',
  templateUrl: './cart-list.component.html',
  styleUrls: ['./cart-list.component.css']
})
export class CartListComponent implements OnInit {

  @Input()
  cartList: Cart[];

  @Output()
  triggerEventToParent: EventEmitter<0> = new EventEmitter();

  constructor(private _cartServ: CartService, private router: Router) { }

  ngOnInit() {
  }

  removeItem(cart: Cart) {
    this._cartServ.deleteCartById(cart.id); // To remove data from local storage
    this.cartList.splice(_.indexOf(this.cartList, cart), 1); // This resove data from class level array
    this.triggerEventToParent.emit();
  }

  changeDetected(cart: Cart) {
    this.triggerEventToParent.emit();
    this._cartServ.updateCart(cart);
  }

  navigateToView(cart) {
    this.router.navigate([`product/view/${cart.productId}`]);
  }
}
