import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../shared/services/auth.service';
import { User } from '../../../shared/models/user';
import { MatSnackBar } from '@angular/material';
import {Observable} from 'rxjs';
import {startWith, map, debounceTime, distinctUntilChanged} from 'rxjs/operators';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  forgotForm: FormGroup = this._fb.group({
    email: ['', Validators.required],
  });
  isUserAlreadyRegistered = false;
  allowToChangePassword = false;
  user: User;
  emailObservable: Observable<string>;
  constructor(private _fb: FormBuilder, private _authServ: AuthService,
              private snackBar: MatSnackBar, private router: Router) { }

  ngOnInit() {
    this.emailObservable = this.forgotForm.get('email').valueChanges
    .pipe(
      debounceTime(500),
      distinctUntilChanged()
    );

    this.emailObservable
    .subscribe(name => {
      this._authServ.isUserRegistered(name)
      .subscribe(res => {
        if (!res.result) {
          this.isUserAlreadyRegistered = false;
          this.snackBar.open('Email does not exists..', 'Enter Registered Email', {
            duration: 2000,
          });
        } else {
          this.isUserAlreadyRegistered = true;
          this._authServ.getUserByEmail(name)
          .subscribe(result => {
            if (result[0].loginType === 'S') {
              this.snackBar.open('Can not update password', 'User Signed in using Google', {
                duration: 2000,
              });
            } else {
              this.user = result[0];
            }
          });
        }
      });
    });
  }

  checkSecurityQuestion(answer: any) {
    if (this.user.securityQuestionAnswer === answer) {
      this.allowToChangePassword = true;
    }
  }

  updateUser(newPassword: any) {
    this.user.password = newPassword;
    this._authServ.updateUser(this.user)
    .subscribe(res => {
      console.log('user credentials updated', 'And logging out');
      this.snackBar.open('Password Updated', 'Please LogIn to Access Account', {
        duration: 4000,
      });
      this.router.navigate([`/auth/login`]);
    });
  }
}
