import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../../shared/services/auth.service';
import { User } from '../../../shared/models/user';
import { UserProfile } from '../../../shared/models/userProfile';
import {HttpResponse} from '@angular/common/http';
import { MatSnackBar } from '@angular/material';
import {Observable} from 'rxjs';
import {startWith, map, debounceTime, distinctUntilChanged} from 'rxjs/operators';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signUpForm: FormGroup = this._fb.group({
    name: ['', Validators.required],
    email: ['', Validators.required],
    password: ['', Validators.required],
    confirmpassword: ['', Validators.required],
    securityQuestion: ['', Validators.required],
    securityQuestionAnswer: ['', Validators.required],
  });

  isUserAlreadyRegistered = true;

  emailObservable: Observable<string>;

  constructor(private _fb: FormBuilder, private _authServ: AuthService,
              private snackBar: MatSnackBar, private router: Router) { }

  ngOnInit() {
    this.emailObservable = this.signUpForm.get('email').valueChanges
    .pipe(
      debounceTime(500),
      distinctUntilChanged()
    );

    this.emailObservable
    .subscribe(name => {
      this._authServ.isUserRegistered(name)
      .subscribe(res => {
        this.isUserAlreadyRegistered = res.result;
        if (res.result) {
          this.snackBar.open('Email already exists..', 'Try with diffrent Email or Log In', {
            duration: 2000,
          });
        }
      });
    });
  }

  signUp(form) {
    if (this.isUserAlreadyRegistered) {
      this.snackBar.open('Email already exists..', 'Try with diffrent Email or Log In', {
        duration: 2000,
      });
    } else {
      const userObj: User = {
        id: null,
        name: form.value.name,
        username: form.value.email,
        password: form.value.password,
        roles: ['user'],
        securityQuestion: form.value.securityQuestion,
        securityQuestionAnswer: form.value.securityQuestionAnswer,
        loginType: 'M'
      };
      this._authServ.registerUser(userObj)
      .subscribe(res => {
        const userProfile: UserProfile = {
          id: null,
          name: res.name,
          username: res.username,
          mobile: 0,
          shipAddress: '',
          pincode: 0,
          cardNo: 0,
          cvv: 0,
          expiry: '',
          userId: res.id
        };

        this._authServ.saveUserProfile(userProfile);
        // Log In User
        this._authServ.authenticate(userObj)
        .subscribe(result => {
          this._authServ.intializeUserAfterLogIn(result);
          this.router.navigateByUrl(this._authServ.redirectUrl || '/');
        });
      },
      (errorResponse: HttpResponse<any>) => {
        if (errorResponse.status === 0) {
          this.snackBar.open('Server not reachable', '', {
            duration: 2000,
          });
        }
      });
    }
    }

    passwordMatchCheck(control:  FormControl):  { [s:  string]:  boolean } {
      if (this.signUpForm) {
      const password = this.signUpForm.get('password').value;
      if (control.value !== password) {
      return { 'passwordMismatch': true };
      }
      return null;
      }
      }
}
