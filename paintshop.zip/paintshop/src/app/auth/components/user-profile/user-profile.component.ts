import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../shared/services/auth.service';
import { UserProfile } from '../../../shared/models/userProfile';
import { User } from '../../../shared/models/user';
import { OrderService } from '../../../order/services/order.service';
import { Order } from '../../../order/models/order';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material';
import { TestimonialService } from '../../../shared/services/testimonial.service';


@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  userData: UserProfile;
  user: User;
  panelOpenState = false;
  numberOfOders = 0;
  orders: Order[];
  confirmPassword;
  editMobileNo = false;
  sortType = 'Latest';
  selectedFile: File = null;
  fileUrl = '';
  feedBackOld;
  comment = '';
  constructor(private _authServ: AuthService, private _orderServ: OrderService,
              private router: Router, private snackBar: MatSnackBar,
              private _testimonialServ: TestimonialService) { }

  ngOnInit() {
    this._authServ.getUserById(this._authServ.getUserId())
    .subscribe(res => {
      this.user = res;
    });

    this._authServ.getUserProfileByUserId(this._authServ.getUserId())
    .subscribe(res => {
      this.userData = res[0];
    });

    this._orderServ.getAllOrdersByUserId(this._authServ.getUserId())
    .subscribe(res => {
      this.numberOfOders = res.length;
      this.orders = res;
    });

    this._testimonialServ.getFeedBackByUserId(this._authServ.getUserId())
    .subscribe(res => {
      this.feedBackOld = res;
      this.comment = res[0].comment;
    });
  }

  viewInvoice(orderId) {
    this.router.navigate([`/order/invoice/${orderId}`]);
  }

  saveUserProfile() {
    this._authServ.updateUserProfile(this.userData);
  }

  changePassword(newPassword) {
    this.user.password = newPassword;
    this._authServ.updateUser(this.user)
    .subscribe(res => {
      console.log('user credentials updated', 'And logging out');
      this._authServ.logOut();
      this.snackBar.open('Password Updated', 'Please Log In Again', {
        duration: 4000,
      });
      this.router.navigate([`/auth/login`]);
    });
  }

  applySort(type) {
    this.sortType = type;
  }

  onFileSelected(event) {
    this.selectedFile = <File> event.target.files[0];
    this._testimonialServ.uploadImage(this.selectedFile)
    .subscribe(res => {
      console.log(res);
      this.fileUrl = res.url;
    });
  }

  saveFeedBack(comment) {
    if (this.feedBackOld === undefined || this.feedBackOld.length === 0) {
       const feedBackObj = {
        id: null,
        userId: this._authServ.getUserId(),
        userName: this._authServ.getUserData().name,
        imageUrl: this.fileUrl,
        comment: comment,
        approved: false,
        date: new Date()
      };

      this._testimonialServ.saveFeedBack(feedBackObj)
      .subscribe();
    } else {
      const feedBackObj = {
        id: this.feedBackOld[0].id,
        userId: this._authServ.getUserId(),
        userName: this._authServ.getUserData().name,
        imageUrl: this.fileUrl === '' ? this.feedBackOld[0].imageUrl : this.fileUrl,
        comment: comment,
        approved: false,
        date: new Date()
      };

      this._testimonialServ.updateFeedBack(feedBackObj)
      .subscribe();
    }
  }
}
