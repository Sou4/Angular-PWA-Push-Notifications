import { Component, OnInit, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {MatSnackBar} from '@angular/material';
import { Router } from '@angular/router';
import { AuthService } from '../../../shared/services/auth.service';
import { User } from '../../../shared/models/user';
import {HttpResponse} from '@angular/common/http';
import { AuthService as SocialAuth } from 'angular5-social-login';
import { GoogleLoginProvider, FacebookLoginProvider } from 'angular5-social-login';
import { UserProfile } from '../../../shared/models/userProfile';
import { _ } from 'underscore';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // Manual Login
  logInForm: FormGroup = this._fb.group({
    userName: ['', Validators.required],
    password: ['', Validators.required],
  });

  constructor(private _fb: FormBuilder, private _authServ: AuthService,
              private snackBar: MatSnackBar, private router: Router,
              private _socialAuth: SocialAuth) { }

  ngOnInit() {
  }

  logIn(form) {
    const userObj: User = {
      id: 1,
      name: '',
      username: form.value.userName,
      password: form.value.password,
      roles: [],
      securityQuestion: '',
      securityQuestionAnswer: '',
      loginType: ''
    };

    this._authServ.authenticate(userObj)
    .subscribe(result => {
      console.log(result);
      this._authServ.intializeUserAfterLogIn(result);
      if (_.indexOf(this._authServ.getUserData().roles, 'admin') !== -1) {
        this.router.navigateByUrl('/admin/dashboad');
      } else if (_.indexOf(this._authServ.getUserData().roles, 'staff') !== -1) {
        this.router.navigateByUrl('/admin/dashboad');
      } else {
        this.router.navigateByUrl(this._authServ.redirectUrl || '/');
      }
    },
    (errorResponse: HttpResponse<any>) => {
      if (errorResponse.status === 0) {
        this.snackBar.open('Server not reachable', '', {
          duration: 2000,
        });
      }
      if (errorResponse.status >= 400) {
        this.snackBar.open('Unable Recognise User', 'Please Check User Name / Password', {
          duration: 2000,
        });
      }
    });
  }

  // Social Log In
  signInWithGoogle(): void {
    this._socialAuth.signIn(GoogleLoginProvider.PROVIDER_ID)
    .then(response => {
      this._authServ.getUserByEmail(response.email)
      .subscribe(user => {
        if (user.length > 0) {
          if (user[0].loginType === 'S') {
             // Log In User
             const userObj: User = {
              id: null,
              name: response.name,
              username: response.email,
              password: response.id,
              roles: ['user'],
              securityQuestion: '',
              securityQuestionAnswer: '',
              loginType: 'S'
            };

             this._authServ.authenticate(userObj)
             .subscribe(result => {
               this._authServ.intializeUserAfterLogIn(result);
               this.router.navigateByUrl(this._authServ.redirectUrl || '/');
             });
          } else {
            this.snackBar.open('Email Already Exist', 'Please use manual log in.', {
              duration: 2000,
            });
          }
        } else {
          const userObj: User = {
            id: null,
            name: response.name,
            username: response.email,
            password: response.id,
            roles: ['user'],
            securityQuestion: '',
            securityQuestionAnswer: '',
            loginType: 'S'
          };
          this._authServ.registerUser(userObj)
          .subscribe(res => {
            const userProfile: UserProfile = {
              id: null,
              name: res.name,
              username: res.username,
              mobile: 0,
              shipAddress: '',
              pincode: 0,
              cardNo: 0,
              cvv: 0,
              expiry: '',
              userId: res.id
            };

            this._authServ.saveUserProfile(userProfile);
            // Log In User
            this._authServ.authenticate(userObj)
            .subscribe(result => {
              this._authServ.intializeUserAfterLogIn(result);
              this.router.navigateByUrl(this._authServ.redirectUrl || '/');
            });
          },
          (errorResponse: HttpResponse<any>) => {
            if (errorResponse.status === 0) {
              this.snackBar.open('Server not reachable', '', {
                duration: 2000,
              });
            }
          });
        }
      });
    });
  }
}
