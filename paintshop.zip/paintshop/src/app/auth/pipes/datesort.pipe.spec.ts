import { DatesortPipe } from './datesort.pipe';

describe('DatesortPipe', () => {
  it('create an instance', () => {
    const pipe = new DatesortPipe();
    expect(pipe).toBeTruthy();
  });
});
