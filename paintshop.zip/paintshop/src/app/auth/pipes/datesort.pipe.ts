import { Pipe, PipeTransform } from '@angular/core';
import { Order } from '../../order/models/order';

@Pipe({
  name: 'datesort'
})

export class DatesortPipe implements PipeTransform {

  transform(orders: Order[], orderType: string): any {

    if (!orders || !orderType) {
      return orders;
    }

    return orders.sort ( (left, right) => {
      if (orderType === 'asc') {
        if ((new Date(left.invoiceDate).getTime()) < (new Date(right.invoiceDate).getTime())) {
          return -1;
        } else {
          return 1;
        }
      } else {
        if ((new Date(left.invoiceDate).getTime()) < (new Date(right.invoiceDate).getTime())) {
          return 1;
        } else {
          return -1;
        }
      }
    });
  }

}
