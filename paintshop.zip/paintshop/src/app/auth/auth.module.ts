import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { Routes, RouterModule } from '@angular/router';
import { FlexLayoutModule } from '@angular/flex-layout';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { MatButtonModule, MatIconModule, MatCardModule, MatInputModule, MatSnackBarModule,
        MatExpansionModule, MatSelectModule} from '@angular/material';
import { UserProfileComponent } from './components/user-profile/user-profile.component';
import { OrderService } from '../order/services/order.service';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { AuthGuard } from '../shared/guards/auth-guard';
import { SharedModule } from '../shared/shared.module';
import { IsLoggedGuard } from '../shared/guards/islogged-guard';
import { DatesortPipe } from './pipes/datesort.pipe';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    canActivate : [IsLoggedGuard]
  },
  {
    path: 'signup',
    component: SignupComponent,
    canActivate : [IsLoggedGuard]
  },
  {
    path: 'userProfile',
    component: UserProfileComponent,
    canActivate : [AuthGuard]
  },
  {
    path: 'forgotPassword',
    component: ForgotPasswordComponent,
    canActivate : [IsLoggedGuard]
  }
];

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes),
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatInputModule,
    MatSnackBarModule,
    FlexLayoutModule,
    MatExpansionModule,
    MatSelectModule,
    SharedModule
  ],
  declarations: [LoginComponent, SignupComponent, UserProfileComponent, ForgotPasswordComponent, DatesortPipe],
  providers: [
    OrderService
  ]
})
export class AuthModule { }
