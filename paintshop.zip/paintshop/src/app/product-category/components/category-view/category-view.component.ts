import { Component, Input, OnChanges } from '@angular/core';
import { ProductService } from '../../../shared/services/product.service';
import { Product } from '../../../shared/models/product';

@Component({
  selector: 'app-category-view',
  templateUrl: './category-view.component.html',
  styleUrls: ['./category-view.component.css']
})
export class CategoryViewComponent implements OnChanges {

  @Input()
  category;

  productList: Product[];

  constructor(private _productServ: ProductService) { }

  ngOnChanges() {
    this._productServ.getProductByCategoryWithSort(this.category.name, 'Popularity', 0, 10000000000, 1)
    .subscribe(res => this.productList = res);
  }
}
