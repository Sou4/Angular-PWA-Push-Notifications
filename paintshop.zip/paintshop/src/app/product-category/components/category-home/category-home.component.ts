import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../../services/category.service';
import { ActivatedRoute, Params } from '@angular/router';

@Component({
  selector: 'app-category-home',
  templateUrl: './category-home.component.html',
  styleUrls: ['./category-home.component.css']
})
export class CategoryHomeComponent implements OnInit {
  category;
  constructor(private _categoryServ: CategoryService, private route: ActivatedRoute) { }

  ngOnInit() {

    this.route.params.subscribe((params: Params) => {
      this._categoryServ.getProductCategoryById(params.id)
      .subscribe(res => {
        this.category = res;
      });
   });

  }

}
