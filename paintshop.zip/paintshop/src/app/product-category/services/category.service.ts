import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { environment } from './../../../environments/environment';
import { ProductCategory } from '../models/product-category';

@Injectable()
export class CategoryService {

  constructor(private http: HttpClient) { }

  getProductCategories(): Observable<ProductCategory[]> {
    return this.http.get<ProductCategory[]>(`${environment.apiEndPoint}/api/category`);
  }

  getProductCategoryById(id: any): Observable<ProductCategory> {
    return this.http
          .get<ProductCategory>(`${environment.apiEndPoint}/api/category/${id}`);
  }
}
