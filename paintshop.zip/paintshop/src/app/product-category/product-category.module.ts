import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CategoryService } from './services/category.service';
import { Routes, RouterModule } from '@angular/router';
import { CategoryHomeComponent } from './components/category-home/category-home.component';
import { CategoryViewComponent } from './components/category-view/category-view.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { SharedModule } from '../shared/shared.module';

const routes: Routes = [
  {
    path: 'home/:id',
    component: CategoryHomeComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FlexLayoutModule,
    SharedModule
  ],
  declarations: [CategoryHomeComponent, CategoryViewComponent],
  providers: [CategoryService]
})
export class ProductCategoryModule { }
