import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatToolbarModule, MatSidenavModule, MatIconModule,
        MatListModule, MatInputModule, MatBadgeModule, MatSnackBarModule } from '@angular/material';
import { MainNavComponent } from './app-components/main-nav/main-nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HomeBannerComponent } from './app-components/home-banner/home-banner.component';
import { HomePageComponent } from './app-components/home-page/home-page.component';
import { FooterComponent } from './app-components/footer/footer.component';
import { CategoryService } from './product-category/services/category.service';
import {FlexLayoutModule} from '@angular/flex-layout';
import { SharedModule } from './shared/shared.module';
import { NgProgressModule, NgProgressInterceptor } from 'ngx-progressbar';
import { AuthService } from './shared/services/auth.service';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { TestimonialsComponent } from './app-components/testimonials/testimonials.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { ProductSearchComponent } from './app-components/product-search/product-search.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { InterceptorService } from './shared/services/interceptor.service';

@NgModule({
  declarations: [
    AppComponent,
    MainNavComponent,
    HomeBannerComponent,
    HomePageComponent,
    FooterComponent,
    TestimonialsComponent,
    ProductSearchComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    HttpClientModule,
    MatButtonModule,
    LayoutModule,
    MatToolbarModule,
    MatSidenavModule,
    MatIconModule,
    MatListModule,
    MatInputModule,
    MatBadgeModule,
    FlexLayoutModule,
    SharedModule.forSharedServiceSingleInstance(),
    NgProgressModule,
    MatSnackBarModule,
    InfiniteScrollModule,
    FormsModule,
    ReactiveFormsModule,
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [
    CategoryService,
    AuthService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: NgProgressInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: InterceptorService,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
