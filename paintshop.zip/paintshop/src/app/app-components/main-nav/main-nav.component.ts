import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { CategoryService } from '../../product-category/services/category.service';
import { CartService } from '../../shared/services/cart.service';
import { AuthService } from '../../shared/services/auth.service';
import { Router } from '@angular/router';
import { AuthService as SocialAuth } from 'angular5-social-login';
import { _ } from 'underscore';
import { SwPush } from '@angular/service-worker';


@Component({
  selector: 'app-main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.css']
})
export class MainNavComponent implements OnInit {
  // Web Push Key
  readonly VAPID_PUBLIC_KEY = 'BE3KRLDGZjcW1U1F5b-GhOYPz5_Lt2QgHbPrOXgTIDOUpguTqIWL6FUSWkSTy9mhAjirIbfJUgMWBfRVF9rfNq0';

  productCategories;
  cartCount;
  isHandset: Observable<BreakpointState> = this.breakpointObserver.observe(Breakpoints.Handset);
  isLogged = false;
  loggedUserName = '';
  isUser = true;
  showSearch = false;
  constructor(private breakpointObserver: BreakpointObserver,
              private _categoryServ: CategoryService, private _cartServ: CartService,
              private _authServ: AuthService, private router: Router,
              private _socialServ: SocialAuth, private swPush: SwPush) {
      this._categoryServ.getProductCategories()
      .subscribe(res => this.productCategories = res);

      this._cartServ.currentCartCount.subscribe(res => {
        this.cartCount = res;
        console.log('Cart Count: ' + res);
      });

      this._authServ.loggedUserNameObsv
      .subscribe(res => {
        if (res === '') {
          this.isLogged = false;
          this.loggedUserName = '';
          this.isUser = true;
        } else {
          this.isLogged = true;
          this.loggedUserName = res;

          // Check for User Role
          if (_.indexOf(this._authServ.getUserData().roles, 'admin') !== -1) {
            console.log('isAdmin');
            this.isUser = false;
          } else if (_.indexOf(this._authServ.getUserData().roles, 'staff') !== -1) {
            console.log('isStaff');
            this.isUser = false;
          } else {
            this.subscribeToNotifications();
          }
        }
        this._cartServ.updateCartCount();
      });
    }

    logOut () {
      this._authServ.logOut();
      this._socialServ.signOut();
      this.router.navigateByUrl('/');
    }

    ngOnInit() { }

    subscribeToNotifications() {
      this.swPush.requestSubscription({
        serverPublicKey: this.VAPID_PUBLIC_KEY
      })
      .then(sub => {
        console.log('Notification Subscription: ', sub);
        const obj = {
          username: this._authServ.getUserData().username,
          userId: this._authServ.getUserId(),
          subscriptionObj: sub
        };
        this._authServ.addPushSubscriber(obj)
        .subscribe(res => {
          console.log('successfully subscribed');
        });
      })
      .catch(err => console.error('Could not subscribe to notifications', err));
    }

    showSearchMenu() {
      this.showSearch = true;
    }

    closeSearchMenu() {
      this.showSearch = false;
    }

    eventTriggered(event) {
      this.showSearch = false;
    }
}
