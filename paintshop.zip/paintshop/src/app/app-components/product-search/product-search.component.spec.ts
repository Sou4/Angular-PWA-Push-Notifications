import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ProductService } from '../../shared/services/product.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Routes, Router } from '@angular/router';
import {Location} from '@angular/common';
import { ProductSearchComponent } from './product-search.component';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
const routes: Routes = [
  {
    path: 'product',
    loadChildren: './product/product.module#ProductModule'
  }
];

const tempServiceStub = {
  searchProducts(a: any) {
    return of( [{id: 1, name: '24 carat'}] );
  }
};

describe('ProductSearchComponent', () => {
  let router: Router;
  let location: Location;
  let component: ProductSearchComponent;
  let fixture: ComponentFixture<ProductSearchComponent>;

  beforeEach((() => {
    TestBed.configureTestingModule({
      declarations: [ ProductSearchComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      imports: [FlexLayoutModule, FormsModule,
                ReactiveFormsModule, HttpClientModule, RouterTestingModule.withRoutes(routes)],
      providers: [{provide: ProductService, useValue: tempServiceStub}]
    })
    .compileComponents();
    fixture = TestBed.createComponent(ProductSearchComponent);
    component = fixture.componentInstance;
    router = TestBed.get(Router);
    location = TestBed.get(Location);
    router.initialNavigation();
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  // fit('should create3', () => {
  //   component.ngOnInit();
  //   component.searchForm.setValue({
  //     searchText : '24 carat'
  //   });
  //   component.searchObservable.subscribe(res => {
  //     console.log('F' + res);
  //   });
  //   console.log(component.products);
  //   expect(component).toBeTruthy();
  // });

  // fit('...', async () => {
  //   fixture.detectChanges();
  //   component.searchForm.setValue({
  //     searchText : '24 carat'
  //   });
  //   await 100000000;
  //   console.log(component.products);
  //   expect(1).toBe(0);
  // });
});
