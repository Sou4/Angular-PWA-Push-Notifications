import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ProductService } from '../../shared/services/product.service';
import {FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Observable} from 'rxjs';
import {debounceTime, distinctUntilChanged} from 'rxjs/operators';
import { Product } from '../../shared/models/product';
import { Router } from '@angular/router';
import {
  trigger,
  animate,
  style,
  transition,
} from '@angular/animations';
@Component({
  selector: 'app-product-search',
  templateUrl: './product-search.component.html',
  styleUrls: ['./product-search.component.css'],
  animations: [
    trigger('productSearchState', [
      transition('void => active', [
        style({transform: 'translateX(-70%) scale(1.2)'}),
        animate(300)
      ])
    ])
  ]
})
export class ProductSearchComponent implements OnInit {
  searchForm: FormGroup = this._fb.group({
    searchText: ['']
  });
  searchObservable: Observable<string>;
  products: Product[];
  @Output() triggerEventToParent: EventEmitter<0> = new EventEmitter();
  constructor(private _productServ: ProductService, private _fb: FormBuilder,
              private router: Router) { }

  ngOnInit() {
    this.searchObservable = this.searchForm.get('searchText').valueChanges
    .pipe(
      debounceTime(500),
      distinctUntilChanged()
    );

    this.searchObservable
    .subscribe(text => {
      console.log(text);
      if ( text !== '') {
        this._productServ.searchProducts(text)
        .subscribe(res => {
          this.products = res;
        });
      } else {
        this.products = [];
      }
    });
  }

  viewProduct(product) {
    this.triggerEventToParent.emit();
    this.router.navigate([`product/view/${product.id}`]);
  }
}
