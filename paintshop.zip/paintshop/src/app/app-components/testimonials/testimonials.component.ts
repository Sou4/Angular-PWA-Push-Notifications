import { Component, OnInit } from '@angular/core';
import { TestimonialService } from '../../shared/services/testimonial.service';

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.css']
})
export class TestimonialsComponent implements OnInit {
  feedbacks = [];
  constructor(private _testimonialSev: TestimonialService) { }

  ngOnInit() {
    this._testimonialSev.getFeedBacks()
    .subscribe(res => {
      console.log(res);
      res.forEach(element => {
        if (element.approved) {
          this.feedbacks.push(element);
        }
      });
    });
  }
}
