import { NgModule } from '@angular/core';
import { Routes, RouterModule, CanActivate } from '@angular/router';
import { HomePageComponent } from './app-components/home-page/home-page.component';
import { AuthGuard } from './shared/guards/auth-guard';
import { AdminAccessGuard } from './shared/guards/adminaccess-guard';

const routes: Routes = [
  {
    path: '',
    component: HomePageComponent
  },
  {
    path: 'other',
    loadChildren: './others/others.module#OthersModule'
  },
  {
    path: 'category',
    loadChildren: './product-category/product-category.module#ProductCategoryModule'
  },
  {
    path: 'product',
    loadChildren: './product/product.module#ProductModule'
  },
  {
    path: 'cart',
    loadChildren: './cart/cart.module#CartModule'
  },
  {
    path: 'auth',
    loadChildren: './auth/auth.module#AuthModule'
  },
  {
    path: 'order',
    loadChildren: './order/order.module#OrderModule',
    canActivate : [AuthGuard]
  },
  {
    path: 'admin',
    loadChildren: './admin/admin.module#AdminModule',
    canActivate : [AuthGuard, AdminAccessGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
