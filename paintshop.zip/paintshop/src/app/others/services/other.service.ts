import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import { City } from '../models/city';
import { Store } from '../models/store';
import { BookConsultant } from '../models/consultantBooks';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class OtherService {

  constructor(private http: HttpClient) { }

  getAllCities(): Observable<City[]> {
    return this.http.get<City[]>(`${environment.apiEndPoint}/api/cities`);
  }

  // Gets only first 10 records
  getCities(): Observable<City[]> {
    return this.http.get<City[]>(`${environment.apiEndPoint}/api/cities?_page=1`);
  }

  searchForStores(searchText: String): Observable<Store[]> {
    return this.http.get<Store[]>(`${environment.apiEndPoint}/api/stores?q=${searchText}`);
  }

  bookConsultant(obj: BookConsultant): Observable<any> {
    return this.http.post(`${environment.apiEndPoint}/api/consultantBookings`, obj);
  }

  getAllConsultantBookings(): Observable<BookConsultant[]> {
    return this.http.get<BookConsultant[]>(`${environment.apiEndPoint}/api/consultantBookings`);
  }

  updateBookConsultant(obj: BookConsultant): Observable<any> {
    return this.http.put(`${environment.apiEndPoint}/api/consultantBookings/${obj.id}`, obj);
  }
}
