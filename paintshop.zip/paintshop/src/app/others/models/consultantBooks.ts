export class BookConsultant {
    id: number;
    name:  string;
    email: string;
    mobileNo: number;
    pincode: number;
    address: string;
    date: string;
    status: string;
}
