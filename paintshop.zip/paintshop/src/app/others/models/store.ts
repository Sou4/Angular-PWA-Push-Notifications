export class Store {
    id: number;
    name: string;
    city: string;
    address: string;
}
