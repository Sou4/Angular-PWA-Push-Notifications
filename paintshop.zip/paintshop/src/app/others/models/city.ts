export class City {
    id: number;
    name: string;
    state: string;
    stateId: number;
}
