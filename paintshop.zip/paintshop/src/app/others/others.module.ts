import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StorelocatorComponent } from './components/storelocator/storelocator.component';
import { Routes, RouterModule } from '@angular/router';
import { OtherService } from './services/other.service';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatFormFieldModule, MatInputModule, MatAutocompleteModule, MatSnackBarModule } from '@angular/material';
import { BookConsultantComponent } from './components/book-consultant/book-consultant.component';

const routes: Routes = [
  {
    path: 'storelocator',
    component: StorelocatorComponent
  },
  {
    path: 'bookConsultant',
    component: BookConsultantComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    FlexLayoutModule,
    MatFormFieldModule,
    MatInputModule,
    MatAutocompleteModule,
    MatSnackBarModule
  ],
  declarations: [StorelocatorComponent, BookConsultantComponent],
  providers: [OtherService]
})
export class OthersModule { }
