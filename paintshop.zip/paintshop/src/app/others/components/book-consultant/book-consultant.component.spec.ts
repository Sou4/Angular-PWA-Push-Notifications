import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { BookConsultantComponent } from './book-consultant.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { OtherService } from '../../services/other.service';
import { RouterTestingModule } from '@angular/router/testing';
import {Routes, Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import {MatSnackBarModule, MatAutocompleteModule} from '@angular/material';
import {Location} from '@angular/common';
import { HomePageComponent } from '../../../app-components/home-page/home-page.component';
import { Observable } from 'rxjs';
import 'rxjs/add/observable/of';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AuthGuard } from '../../../shared/guards/auth-guard';
import { PlaceOrderComponent } from '../../../order/components/place-order/place-order.component';
import { StorelocatorComponent } from '../storelocator/storelocator.component';
import { AuthService } from '../../../shared/services/auth.service';
import { LoginComponent } from '../../../auth/components/login/login.component';

const routes: Routes = [
  {
    path: '',
    component: HomePageComponent
  },
  {
    path: 'placeOrder',
    component: PlaceOrderComponent,
    canActivate : [AuthGuard]
  },
  {
    path: 'storelocator',
    component: StorelocatorComponent
  },
  {
    path: 'auth/login',
    component: LoginComponent
  }
];
class TempServiceStub {
  getAllConsultantBookings(a: any): Observable<any> {
    console.log('inside stub getAllConsultantBookings');
    return Observable.of(1);
  }

  bookConsultant(a: any): Observable<any> {
    console.log('inside stub getAllConsultantBookings');
    return Observable.of(true);
  }
}

class TempAuthServiceStub  {
  isLoggedIn(): boolean {
    if (localStorage.getItem('tempToken')) {
      return true;
    } else  {
      return false;
    }
  }
}

describe('BookConsultantComponent', () => {
  let router: Router;
  let location: Location;
  let component: BookConsultantComponent;
  let fixture: ComponentFixture<BookConsultantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BookConsultantComponent, HomePageComponent, PlaceOrderComponent,
                      StorelocatorComponent, LoginComponent  ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      imports: [FlexLayoutModule, FormsModule, MatSnackBarModule, BrowserAnimationsModule, MatAutocompleteModule,
                ReactiveFormsModule, HttpClientModule, RouterTestingModule.withRoutes(routes)],
      providers: [{provide: OtherService, useClass: TempServiceStub },
        {provide: AuthService, useClass: TempAuthServiceStub },
          AuthGuard]
    })
    .compileComponents();
    fixture = TestBed.createComponent(BookConsultantComponent);
    component = fixture.componentInstance;
    router = TestBed.get(Router);
    location = TestBed.get(Location);
    router.initialNavigation();
    fixture.detectChanges();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BookConsultantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('create book consultant request', async(() => {
    component.ngOnInit();
    component.bookForm.setValue({
      name:  'sourabh',
      email: 'sou@gmail.com',
      mobileNo: '9900991111',
      pincode: '1234940',
      address: '-----'
    });
    component.bookConsultant(component.bookForm);
    expect(location.path()).toBe('/');
  }));

  it('navigate to "storelocator" ', fakeAsync(() => {
    router.navigate(['storelocator']);
    tick();
    expect(location.path()).toBe('/storelocator');
  }));

  it('navigate to "placeOrder" without login ', fakeAsync(() => {
    router.navigate(['placeOrder']);
    tick();
    expect(location.path()).toBe('/placeOrder');
  }));

  it('navigate to "placeOrder" with login ', fakeAsync(() => {
    localStorage.setItem('tempToken', 'sampleToken');
    router.navigate(['placeOrder']);
    tick();
    expect(location.path()).toBe('/placeOrder');
    localStorage.setItem('tempToken', null);
  }));
});
