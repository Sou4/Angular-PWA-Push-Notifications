import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { BookConsultant } from '../../models/consultantBooks';
import { OtherService } from '../../services/other.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-consultant',
  templateUrl: './book-consultant.component.html',
  styleUrls: ['./book-consultant.component.css']
})
export class BookConsultantComponent implements OnInit {
  name: FormControl;
  email: FormControl;
  mobileNo: FormControl;
  pincode: FormControl;
  address: FormControl;

  bookForm: FormGroup;

  constructor(private fb: FormBuilder, private _otherSer: OtherService,
    private snackBar: MatSnackBar, private router: Router) {
    this.name = new FormControl('', [
      Validators.required,
      Validators.minLength(6)
    ]);
    this.email = new FormControl('', [
      Validators.required,
      Validators.email
    ]);

    this.mobileNo = new FormControl('', [
      Validators.required,
      Validators.pattern('^(0|[1-9][0-9]*)$'),
      Validators.minLength(10)
    ]);

    this.pincode = new FormControl('', [
      Validators.required,
      Validators.pattern('^(0|[1-9][0-9]*)$'),
      Validators.minLength(6)
    ]);

    this.address = new FormControl('', [
      Validators.required
    ]);

    this.bookForm = this.fb.group({
      name:  this.name,
      email: this.email,
      mobileNo: this.mobileNo,
      pincode: this.pincode,
      address: this.address
    });
  }

  ngOnInit() {
  }

  bookConsultant(form) {
    console.log(form.value);

    this._otherSer.getAllConsultantBookings()
    .subscribe(bookings => {
      console.log(4);
      console.log(form);
      console.log(bookings);
      const obj: BookConsultant = {
        id: bookings.length + 1,
        name:  form.value.name,
        email: form.value.email,
        mobileNo: form.value.mobileNo,
        pincode: form.value.pincode,
        address: form.value.address,
        date: '' + new Date(),
        status: 'open'
      };

      this._otherSer.bookConsultant(obj)
      .subscribe(res => {
        form.reset();
        this.snackBar.open('Our consultant will contact you shortly' , 'Thank you', {
          duration: 4000
        });
        this.router.navigate([`/`]);
      });
    });

  }

}
