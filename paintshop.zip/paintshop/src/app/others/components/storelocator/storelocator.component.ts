import { Component, OnInit } from '@angular/core';
import { OtherService } from '../../services/other.service';
import {FormGroup, FormBuilder} from '@angular/forms';
import {Observable} from 'rxjs';
import {startWith, map, debounceTime, distinctUntilChanged} from 'rxjs/operators';
import { City } from '../../models/city';
import { Store } from '../../models/store';

@Component({
  selector: 'app-storelocator',
  templateUrl: './storelocator.component.html',
  styleUrls: ['./storelocator.component.css']
})
export class StorelocatorComponent implements OnInit {

  constructor(private _otherServ: OtherService, private fb: FormBuilder) { }

  stores: Store[];
  cities: City[];
  cityOptions: Observable<String | City[]>;
  storeSearchForm: FormGroup = this.fb.group({
    cityName: '',
  });

  ngOnInit() {
    this._otherServ.getCities()
    .subscribe(res => this.cities = res);

    this.cityOptions = this.storeSearchForm.get('cityName').valueChanges
      .pipe(
        debounceTime(500),
        distinctUntilChanged(),
        startWith<String>(''),
        map(name => name ? this.filter(name) : this.cities)
      );

      this.cityOptions.subscribe(res => {
        if (res !== undefined && res.length === 1) {
          this.loadAddresses(res[0]);
        }
      });
    }

    filter(name: String): any {
      return this.cities.filter(option =>
        option.name.toLowerCase().includes(name.toLowerCase()));
    }

    loadAddresses(city: any) {
      this._otherServ.searchForStores(city.name)
      .subscribe(res => this.stores = res);
    }
}
