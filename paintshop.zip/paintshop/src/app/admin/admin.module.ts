import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FlexLayoutModule } from '@angular/flex-layout';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { MatButtonModule, MatIconModule, MatCardModule, MatSnackBarModule} from '@angular/material';
import { ProductsComponent } from './components/products/products.component';
import {
  MatInputModule,
  MatTableModule,
  MatPaginatorModule,
  MatSortModule,
  MatDialogModule,
  MatSelectModule,
  MatChipsModule,
  MatAutocompleteModule,
  MatCheckboxModule
} from '@angular/material';
import { ProductEditComponent } from './components/product-edit/product-edit.component';
import { ProductAddComponent } from './components/product-add/product-add.component';
import { UserComponent } from './components/user/user.component';
import { UserEditComponent } from './components/user-edit/user-edit.component';
import { UserAddComponent } from './components/user-add/user-add.component';
import { AccessGuard } from './guards/access-guard';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { TestimonialsComponent } from './components/testimonials/testimonials.component';
import { ConsultRequestComponent } from './components/consult-request/consult-request.component';
import { OtherService } from '../others/services/other.service';
import { ChartsModule } from 'ng2-charts';
import { SharedModule } from '../shared/shared.module';
import { OrderService } from '../order/services/order.service';
import { PushNotificationComponent } from './components/push-notification/push-notification.component';

const routes: Routes = [
  {
    path: 'products',
    component: ProductsComponent,
    canActivate : [AccessGuard],
    data:  ['products']
  },
  {
    path: 'user',
    component: UserComponent,
    canActivate : [AccessGuard],
    data:  ['user']
  },
  {
    path: 'dashboad',
    component: DashboardComponent,
    canActivate : [AccessGuard],
    data:  ['home']
  },
  {
    path: 'testimonials',
    component: TestimonialsComponent,
    canActivate : [AccessGuard],
    data:  ['testimonials']
  },
  {
    path: 'consultantRequest',
    component: ConsultRequestComponent,
    canActivate : [AccessGuard],
    data:  ['consultantRequest']
  },
  {
    path: 'pushNotification',
    component: PushNotificationComponent,
    canActivate : [AccessGuard],
    data:  ['pushNotification']
  }
];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSnackBarModule,
    MatInputModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatDialogModule,
    MatSelectModule,
    MatChipsModule,
    MatAutocompleteModule,
    MatCheckboxModule,
    ChartsModule,
    SharedModule
  ],
  entryComponents: [ProductEditComponent, ProductAddComponent, UserEditComponent,
                    UserAddComponent],
  declarations: [ProductsComponent, ProductEditComponent, ProductAddComponent,
                   UserComponent, UserEditComponent, UserAddComponent, DashboardComponent,
                    TestimonialsComponent, ConsultRequestComponent, PushNotificationComponent],
  providers: [AccessGuard, OtherService, OrderService]
})
export class AdminModule { }
