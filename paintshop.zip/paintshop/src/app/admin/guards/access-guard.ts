import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../../shared/services/auth.service';
import { _ } from 'underscore';

@Injectable()
export class AccessGuard implements CanActivate {
    constructor (private _authService: AuthService,
        private router: Router) { }


    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {

            if (_.indexOf(this._authService.getUserData().roles, 'admin') !== -1) {
                return true;
            } else if (_.indexOf(this._authService.getUserData().roles, 'staff') !== -1) {
            const user: any = this._authService.getUserData();
            if (_.indexOf(user.assignedScreens, route.data[0]) !== -1) {
                console.log('has permission to : ' + route.data[0]);
                return true;
            } else {
                window.alert('You don\'t have access... Contact Admin');
                this.router.navigateByUrl('/admin/dashboad');
                return false;
            }
         } else if (_.indexOf(this._authService.getUserData().roles, 'user') !== -1) {
            window.alert('You don\'t have access');
            this.router.navigateByUrl('/');
            return false;
         } else {
            window.alert('You don\'t have access');
            this.router.navigateByUrl('/');
            return false;
         }
    }
}
