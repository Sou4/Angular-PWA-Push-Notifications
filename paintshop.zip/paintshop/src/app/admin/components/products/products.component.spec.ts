import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HttpClientModule } from '@angular/common/http';
import { ProductsComponent } from './products.component';
import { ProductService } from '../../../shared/services/product.service';
import {MatDialogModule, MatDialogRef,  MAT_DIALOG_DATA} from '@angular/material/dialog';
import {MatTableModule} from '@angular/material';

describe('ProductsComponent', () => {
  let component: ProductsComponent;
  let fixture: ComponentFixture<ProductsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductsComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      imports: [FlexLayoutModule, HttpClientModule, MatDialogModule, MatTableModule],
      providers: [
        ProductService,
        {
          provide:  MAT_DIALOG_DATA,
          useValue:  { }
        },
        {
          provide:  MatDialogRef,
          useValue:  {  }
        }
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
