import { Component, OnInit, ViewChild } from '@angular/core';
import { ProductService } from '../../../shared/services/product.service';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import { Product } from '../../../shared/models/product';
import { ProductEditComponent } from '../product-edit/product-edit.component';
import { ProductAddComponent } from '../product-add/product-add.component';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  displayedColumns = ['image', 'name' , 'category', 'action'];
  dataSource: MatTableDataSource<Product>;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private _prodServ: ProductService, public dialog: MatDialog) { }

  ngOnInit() {
    this._prodServ.getAllProducts()
    .subscribe(res => {
        this.dataSource = new MatTableDataSource(res);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  delete(product: Product) {
    if (window.confirm('Do you want delete ?')) {
      this._prodServ.deleteProductById(product.id)
      .subscribe(res => {
        console.log(res);
        this.dataSource.data.splice(this.dataSource.data.indexOf(product), 1);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      });
    }
  }

  edit(product: Product) {
    this.dialog.open(ProductEditComponent, {
      width: '450px',
      data: product
    });
  }

  add() {
    const dialogRef = this.dialog.open(ProductAddComponent, {
      width: '450px',
      data: new Product,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        this.dataSource.data.push(result);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }
}
