import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../shared/services/product.service';
import { AuthService } from '../../../shared/services/auth.service';
import { _ } from 'underscore';
import { OrderService } from '../../../order/services/order.service';

interface ProductOccurances {
  name: string;
  count: number;
  category: string;
}

interface CategoryOccurances {
  name: string;
  count: number;
}

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})


export class DashboardComponent implements OnInit {
  productCount = 0;
  userCount = 0;
  orederCount = 0;
  revenue = 0;

  // Chart
  // Doughnut
  doughnutChartLabels;
  doughnutChartData;
  doughnutChartType = 'doughnut';

   // Pie
   public pieChartLabels;
   public pieChartData;
   public pieChartType = 'pie';
  constructor(private _productServ: ProductService, private _authServ: AuthService,
              private _orderServ: OrderService) { }

  ngOnInit() {
    this._productServ.getAllProducts()
    .subscribe(res => {
      this.productCount = res.length;
    });

    this._authServ.getAllUsers()
    .subscribe(res => {
      res.forEach(element => {
        if (!element.roles.includes('admin')) {
          if (!element.roles.includes('staff')) {
            ++this.userCount;
          }
        }
      });
    });

    this._orderServ.getAllOrders()
    .subscribe(res => {
      this.orederCount = res.length;
      res.forEach(element => {
        if (!isNaN(element.amountPaid)) {
            this.revenue += element.amountPaid;
        }
      });

      const productOccurances: ProductOccurances[] = [];
     _.pluck(res, 'products').forEach(element => {
        element.forEach(element2 => {
          if (productOccurances.length !== 0) {
            let isproductFound = false;
            productOccurances.forEach(element3 => {
                if (element3.name === element2.productName) {
                  isproductFound = true;
                  element3.count += element2.qty;
                  return false;
                }
            });
            if (!isproductFound) {
              productOccurances.push({
                name: element2.productName,
                count: element2.qty,
                category: element2.productCategory
              });
            }
          } else {
            productOccurances.push({
              name: element2.productName,
              count: element2.qty,
              category: element2.productCategory
            });
          }
        });
      });

      productOccurances.sort((item1, item2) => {
        return item2.count - item1.count;
      });

      const doughnutChartLabels = [];
      const doughnutChartData = [];
      productOccurances.forEach(element => {
        if (doughnutChartLabels.length < 5) {
          doughnutChartLabels.push(element.name);
          doughnutChartData.push(element.count);
        }
      });
      this.doughnutChartLabels = doughnutChartLabels;
      this.doughnutChartData = doughnutChartData;

      // console.log(productOccurances);
      const categoryOccurances: CategoryOccurances[] = [];
      productOccurances.forEach(element => {
        if (categoryOccurances.length !== 0) {
          let iscategoryFound = false;
          categoryOccurances.forEach(element3 => {
              if (element.category === element3.name) {
                iscategoryFound = true;
                element3.count += element.count;
                return false;
              }
          });
          if (!iscategoryFound) {
            categoryOccurances.push({
              name: element.category,
              count: element.count
            });
          }
        } else {
          categoryOccurances.push({
            name: element.category,
            count: element.count
          });
        }
      });
      // console.log(categoryOccurances);
      const pieChartLabels = [];
      const pieChartData = [];
      categoryOccurances.forEach(element => {
          pieChartLabels.push(element.name);
          pieChartData.push(element.count);
      });
      this.pieChartLabels = pieChartLabels;
      this.pieChartData = pieChartData;
    });
  }

}
