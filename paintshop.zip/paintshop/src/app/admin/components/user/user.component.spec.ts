import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HttpClientModule } from '@angular/common/http';
import {MatDialogModule, MatDialogRef,  MAT_DIALOG_DATA} from '@angular/material/dialog';
import {MatTableModule, MatSnackBarModule} from '@angular/material';
import { AuthService } from '../../../shared/services/auth.service';

import { UserComponent } from './user.component';

describe('UserComponent', () => {
  let component: UserComponent;
  let fixture: ComponentFixture<UserComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      imports: [FlexLayoutModule, HttpClientModule, MatDialogModule, MatTableModule, MatSnackBarModule],
      providers: [
        AuthService,
        {
          provide:  MAT_DIALOG_DATA,
          useValue:  { }
        },
        {
          provide:  MatDialogRef,
          useValue:  {  }
        }
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
