import { Component, OnInit, ViewChild } from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import { AuthService } from '../../../shared/services/auth.service';
import { _ } from 'underscore';
import { UserEditComponent } from '../../components/user-edit/user-edit.component';
import { UserAddComponent } from '../../components/user-add/user-add.component';
import { User } from '../../../shared/models/user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  displayedColumns = [ 'name', 'username', 'action'];
  dataSource: MatTableDataSource<any>;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private _authServ: AuthService, public dialog: MatDialog) { }

  ngOnInit() {
    this._authServ.getAllUsers()
    .subscribe(res => {
      const userList = [];
      res.forEach(element => {
        if (_.indexOf(element.roles, 'admin') !== -1) {
          userList.push(element);
        } else if (_.indexOf(element.roles, 'staff') !== -1) {
          userList.push(element);
        }
      });

      this.dataSource = new MatTableDataSource(userList);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  add() {
    const dialogRef = this.dialog.open(UserAddComponent, {
      width: '450px',
      data: new User,
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result !== undefined) {
        this.dataSource.data.push(result);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      }
    });
  }

  edit(user) {
    this.dialog.open(UserEditComponent, {
      width: '450px',
      data: user
    });
  }

  delete(user) {
    if (window.confirm('Do you want delete ?')) {
      this._authServ.deleteUserById(user.id)
      .subscribe(res => {
        console.log(res);
        this.dataSource.data.splice(this.dataSource.data.indexOf(user), 1);
        this.dataSource.sort = this.sort;
        this.dataSource.paginator = this.paginator;
      });
    }
  }
}
