import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../../shared/services/auth.service';

@Component({
  selector: 'app-push-notification',
  templateUrl: './push-notification.component.html',
  styleUrls: ['./push-notification.component.css']
})
export class PushNotificationComponent implements OnInit {

  constructor(private _authServ: AuthService) { }

  ngOnInit() {
  }

  sendNotification(title, content) {
    console.log(title, content);
    const obj = {
      titile : title,
      desc : content
    };
    this._authServ.sendNotifiactions(obj)
    .subscribe(res => {
      console.log('send notification request sent');
    });
  }
}
