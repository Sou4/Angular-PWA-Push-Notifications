import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ConsultRequestComponent } from './consult-request.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { OtherService } from '../../../others/services/other.service';
import {MatTableModule} from '@angular/material';
import { BookConsultant } from '../../../others/models/consultantBooks';
import { HttpClientModule } from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/add/observable/of';

describe('ConsultRequestComponent', () => {
  let component: ConsultRequestComponent;
  let fixture: ComponentFixture<ConsultRequestComponent>;
  let otherService: OtherService;

  let element: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsultRequestComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      imports: [FlexLayoutModule, MatTableModule, HttpClientModule],
      providers: [OtherService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsultRequestComponent);
    component = fixture.componentInstance;
    otherService = fixture.debugElement.injector.get(OtherService);
    otherService.getAllConsultantBookings = function() {
      return Observable.of(<BookConsultant[]> [{id: 1, name: 'Sourabh', email: 'sourabh@gmail.com'}]);
    };
    fixture.detectChanges();
  });

  fit('should create', () => {
    expect(component).toBeTruthy();
  });

  fit('should get one book consultant objects', () => {
    element = fixture.nativeElement;
    expect(element.querySelectorAll('tr').length).toBe(2);
  });

  fit('should two book consultant objects', () => {
    otherService.getAllConsultantBookings = function() {
      return Observable.of(<BookConsultant[]>
        [{id: 1, name: 'Sourabh', email: 'sourabh@gmail.com'},
          {id: 1, name: 'Satish', email: 'satish@gmail.com'}, ]);
    };

    component.ngOnInit();

    fixture.detectChanges();
    element = fixture.nativeElement;

    expect(element.querySelectorAll('tr').length).toBe(3);

    expect(element.querySelectorAll('tr')[1].textContent)
          .toContain('Sourabh');

    expect(element.querySelectorAll('tr')[2].textContent)
          .toContain('Satish');

    expect(element.querySelectorAll('tr')[1].textContent)
    .toContain('sourabh@gmail.com');
  });
});
