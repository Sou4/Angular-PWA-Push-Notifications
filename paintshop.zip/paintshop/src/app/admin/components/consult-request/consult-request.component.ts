import { Component, OnInit, ViewChild } from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import { OtherService } from '../../../others/services/other.service';
import { _ } from 'underscore';

@Component({
  selector: 'app-consult-request',
  templateUrl: './consult-request.component.html',
  styleUrls: ['./consult-request.component.css']
})
export class ConsultRequestComponent implements OnInit {
  displayedColumns = [ 'date', 'name', 'contact', 'Address', 'status'];
  dataSource: MatTableDataSource<any>;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  constructor(private _otherServ: OtherService) { }

  ngOnInit() {
    this._otherServ.getAllConsultantBookings()
    .subscribe(res => {
      this.dataSource = new MatTableDataSource(res);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  updateStatus(data) {
    this._otherServ.updateBookConsultant(data)
    .subscribe();
  }
}
