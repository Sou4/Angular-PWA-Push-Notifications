import { Component, OnInit, ViewChild } from '@angular/core';
import {MatPaginator, MatSort, MatTableDataSource, MatDialog} from '@angular/material';
import { TestimonialService } from '../../../shared/services/testimonial.service';
import { _ } from 'underscore';

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.css']
})
export class TestimonialsComponent implements OnInit {
  displayedColumns = [ 'imageUrl', 'name', 'comment', 'approved'];
  dataSource: MatTableDataSource<any>;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatPaginator;

  constructor(private _testimonialSev: TestimonialService) { }

  ngOnInit() {
    this._testimonialSev.getFeedBacks()
    .subscribe(res => {
      this.dataSource = new MatTableDataSource(res);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  updateFeedBack(status, feedBack) {
    this._testimonialSev.updateFeedBack(feedBack)
    .subscribe();
  }
}
