import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HttpClientModule } from '@angular/common/http';
import { TestimonialService } from '../../../shared/services/testimonial.service';
import {MatDialogModule, MatDialogRef,  MAT_DIALOG_DATA} from '@angular/material/dialog';
import {MatTableModule} from '@angular/material';

import { TestimonialsComponent } from './testimonials.component';

describe('TestimonialsComponent', () => {
  let component: TestimonialsComponent;
  let fixture: ComponentFixture<TestimonialsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TestimonialsComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      imports: [FlexLayoutModule, HttpClientModule, MatDialogModule, MatTableModule],
      providers: [
        TestimonialService,
        {
          provide:  MAT_DIALOG_DATA,
          useValue:  { }
        },
        {
          provide:  MatDialogRef,
          useValue:  {  }
        }
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestimonialsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
