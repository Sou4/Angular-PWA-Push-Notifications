import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { AuthService } from '../../../shared/services/auth.service';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { ElementRef, ViewChild} from '@angular/core';
import {FormControl} from '@angular/forms';
import {MatAutocompleteSelectedEvent, MatChipInputEvent} from '@angular/material';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { _ } from 'underscore';

@Component({
  selector: 'app-user-edit',
  templateUrl: './user-edit.component.html',
  styleUrls: ['./user-edit.component.css']
})
export class UserEditComponent implements OnInit {
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = false;

  separatorKeysCodes = [ENTER, COMMA];

  accessCtrl = new FormControl();

  filteredAccess: Observable<any[]>;

  assignedScreens = [
    'Home',
  ];

  allScreens = [
    'home',
    'products',
    'user',
    'testimonials',
    'notification',
    'consultantRequest',
    'pushNotification'
  ];
  @ViewChild('accessInput') accessInput: ElementRef;
  constructor(
    public dialogRef: MatDialogRef<UserEditComponent>,
    @Inject(MAT_DIALOG_DATA) public user: any,
    private _authServ: AuthService) {
      this.assignedScreens = this.user.assignedScreens === undefined ? [] : this.user.assignedScreens;
      this.filteredAccess = this.accessCtrl.valueChanges.pipe(
        startWith(null),
        map((access: string | null) => access ? this.filter(access) : this.allScreens.slice()));
    }

  ngOnInit() {
  }

  save(): void {
    this.assignedScreens = _.uniq(this.assignedScreens);
    this.user.assignedScreens = this.assignedScreens;
    this._authServ.updateUserFromAdmin(this.user)
    .subscribe(res => {
      this.dialogRef.close(res);
    });
  }

  close() {
    this.dialogRef.close();
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      this.assignedScreens.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.accessCtrl.setValue(null);
  }

  remove(access: any): void {
    const index = this.assignedScreens.indexOf(access);

    if (index >= 0) {
      this.assignedScreens.splice(index, 1);
    }
  }

  filter(name: string) {
    return this.allScreens.filter(fruit =>
        fruit.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.assignedScreens.push(event.option.viewValue);
    this.accessInput.nativeElement.value = '';
    this.accessCtrl.setValue(null);
  }
}
