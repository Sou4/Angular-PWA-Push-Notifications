import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FlexLayoutModule } from '@angular/flex-layout';
import { HttpClientModule } from '@angular/common/http';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {MatChipsModule, MatAutocompleteModule, MatSnackBarModule} from '@angular/material';
import { AuthService } from '../../../shared/services/auth.service';
import {MatDialogModule, MatDialogRef,  MAT_DIALOG_DATA} from '@angular/material/dialog';

import { UserAddComponent } from './user-add.component';

describe('UserAddComponent', () => {
  let component: UserAddComponent;
  let fixture: ComponentFixture<UserAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserAddComponent ],
      schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
      imports: [FlexLayoutModule, HttpClientModule, FormsModule, MatAutocompleteModule,
        MatSnackBarModule, ReactiveFormsModule, MatChipsModule, MatDialogModule],
      providers: [
        AuthService,
        {
          provide:  MAT_DIALOG_DATA,
          useValue:  { }
        },
        {
          provide:  MatDialogRef,
          useValue:  {  }
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
