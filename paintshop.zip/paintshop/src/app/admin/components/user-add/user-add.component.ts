import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';
import { AuthService } from '../../../shared/services/auth.service';
import {COMMA, ENTER} from '@angular/cdk/keycodes';
import { ElementRef, ViewChild} from '@angular/core';
import {FormControl, FormGroup, Validators, FormBuilder} from '@angular/forms';
import {MatAutocompleteSelectedEvent, MatChipInputEvent} from '@angular/material';
import {Observable} from 'rxjs';
import {map, startWith, debounceTime, distinctUntilChanged} from 'rxjs/operators';
import { _ } from 'underscore';
import { MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-user-add',
  templateUrl: './user-add.component.html',
  styleUrls: ['./user-add.component.css']
})
export class UserAddComponent implements OnInit {
  visible = true;
  selectable = true;
  removable = true;
  addOnBlur = false;

  separatorKeysCodes = [ENTER, COMMA];

  accessCtrl = new FormControl();

  filteredAccess: Observable<any[]>;

  assignedScreens = [
    'Home',
  ];

  allScreens = [
    'home',
    'products',
    'user',
    'testimonials',
    'notification',
    'consultantRequest',
    'pushNotification'
  ];
  @ViewChild('accessInput') accessInput: ElementRef;

  constructor(
    public dialogRef: MatDialogRef<UserAddComponent>,
    @Inject(MAT_DIALOG_DATA) public user: any, private _fb: FormBuilder,
    private _authServ: AuthService, private snackBar: MatSnackBar) {
      this.assignedScreens = this.user.assignedScreens === undefined ? [] : this.user.assignedScreens;
      this.filteredAccess = this.accessCtrl.valueChanges.pipe(
        startWith(null),
        map((access: string | null) => access ? this.filter(access) : this.allScreens.slice()));
    }

  ngOnInit() {

  }

  save(): void {

    this._authServ.isUserRegistered(this.user.username)
    .subscribe(res => {
      if (res.result) {
        this.snackBar.open('Email already exists..', 'Try with diffrent Email or Log In', {
          duration: 2000,
        });
      } else {
        this.assignedScreens = _.uniq(this.assignedScreens);
        this.user.assignedScreens = this.assignedScreens;
        this.user.id = null;
        this.user.roles = ['staff'];
        this.user.securityQuestion = '';
        this.user.securityQuestionAnswer = '';
        this.user.loginType = 'M';
        this._authServ.saveUser(this.user)
        .subscribe(res2 => {
          this.dialogRef.close(res2);
        });
      }
    });
  }

  close() {
    this.dialogRef.close();
  }

  add(event: MatChipInputEvent): void {
    const input = event.input;
    const value = event.value;

    // Add our fruit
    if ((value || '').trim()) {
      this.assignedScreens.push(value.trim());
    }

    // Reset the input value
    if (input) {
      input.value = '';
    }

    this.accessCtrl.setValue(null);
  }

  remove(access: any): void {
    const index = this.assignedScreens.indexOf(access);

    if (index >= 0) {
      this.assignedScreens.splice(index, 1);
    }
  }

  filter(name: string) {
    return this.allScreens.filter(fruit =>
        fruit.toLowerCase().indexOf(name.toLowerCase()) === 0);
  }

  selected(event: MatAutocompleteSelectedEvent): void {
    this.assignedScreens.push(event.option.viewValue);
    this.accessInput.nativeElement.value = '';
    this.accessCtrl.setValue(null);
  }

  changed(email) {
    console.log(email);
  }

}
