import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../shared/services/product.service';
import { ActivatedRoute, Params } from '@angular/router';
import { Product } from '../../../shared/models/product';
import { CartService } from '../../../shared/services/cart.service';
import { Cart } from '../../../shared/models/cart';

@Component({
  selector: 'app-product-view',
  templateUrl: './product-view.component.html',
  styleUrls: ['./product-view.component.css']
})
export class ProductViewComponent implements OnInit {
  // For Product Details
  product: Product;
  selectedPack = '1';
  qty = 1;

  // For Paint Estimation
  selectedType = 'Fresh';
  noRooms = 1;
  carpetArea = 1;
  estimatedCost;
  totalLtreReq;

  constructor(private _productServ: ProductService, private route: ActivatedRoute,
              private _cartServ: CartService) { }

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      this._productServ.getProductById(params.id)
    .subscribe(res => {
      this.product = res;
    });
   });
  }

  addToCart() {
    const cartObj: Cart = {
      id: this._cartServ.generateNextId(),
      productName: this.product.name,
      productId: this.product.id,
      productCategory: this.product.category,
      selectedPack: this.selectedPack,
      qty: this.qty,
      imageUrl: this.product.image,
      price: this.product.offerprice,
      mrp: this.product.price,
      userId: null,
      rating: this.product.rating
    };
    this._cartServ.addToCart(cartObj);
  }

  estimatePaintCost() {
    this.totalLtreReq = this.carpetArea * this.noRooms * parseFloat(this.product.ltrePerSqFoot);
    this.estimatedCost = this.totalLtreReq * this.product.price;
    if (this.selectedType === 'Repaint') {
      this.estimatedCost += (this.estimatedCost * 0.05); // Additional Cost 5%
    }
  }
}
