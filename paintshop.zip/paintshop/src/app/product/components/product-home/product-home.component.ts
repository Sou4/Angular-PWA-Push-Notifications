import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../shared/services/product.service';
import { Product } from '../../../shared/models/product';

@Component({
  selector: 'app-product-home',
  templateUrl: './product-home.component.html',
  styleUrls: ['./product-home.component.css']
})
export class ProductHomeComponent implements OnInit {

  productList: Product[];

  constructor(private _productServ: ProductService) { }

  ngOnInit() {
    this._productServ.getProductsWithSort('Popularity', 0, 10000000000, 1)
    .subscribe(res => this.productList = res);
  }

  onScrollDown() {
    console.log('kkkk');
  }
}
