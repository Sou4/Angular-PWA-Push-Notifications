import { NgModule, ModuleWithProviders } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductListComponent } from './components/product-list/product-list.component';
import { MatCardModule, MatButtonModule, MatIconModule, MatSidenavModule, MatListModule,
          MatRadioModule, MatSliderModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ProductService } from './services/product.service';
import { CartService } from './services/cart.service';
import { AuthGuard } from './guards/auth-guard';
import { FormsModule } from '@angular/forms';
import { IonRangeSliderModule } from 'ng2-ion-range-slider';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';
import { SocialLoginModule } from 'angular5-social-login';
import { AuthServiceConfig, GoogleLoginProvider  } from 'angular5-social-login';
import { IsLoggedGuard } from './guards/islogged-guard';
import { AdminAccessGuard } from './guards/adminaccess-guard';
import { HighlightDirective } from './directives/highlight.directive';
import { TestimonialService } from './services/testimonial.service';

const config = new AuthServiceConfig([
  {
    id: GoogleLoginProvider.PROVIDER_ID,
    provider: new GoogleLoginProvider('1019625920477-ag3abj0l9un1uta7r6hbfmhjl4gs2vui.apps.googleusercontent.com')
  }
]);
export function provideConfig() {
  return config;
}

@NgModule({
  imports: [
    CommonModule,
    MatCardModule,
    FlexLayoutModule,
    MatButtonModule,
    MatIconModule,
    MatSidenavModule,
    MatListModule,
    MatRadioModule,
    FormsModule,
    MatSliderModule,
    IonRangeSliderModule,
    InfiniteScrollModule,
    SocialLoginModule
  ],
  declarations: [
    ProductListComponent,
    HighlightDirective
  ],
  exports: [
    ProductListComponent,
    HighlightDirective
  ]
})
export class SharedModule {
  static forSharedServiceSingleInstance(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
      providers: [
        {
          provide: AuthServiceConfig,
          useFactory: provideConfig
        },
        ProductService,
        CartService,
        AuthGuard,
        IsLoggedGuard,
        AdminAccessGuard,
        TestimonialService
      ]
    };
  }
}


