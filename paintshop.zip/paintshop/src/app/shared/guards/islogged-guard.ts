import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Injectable()
export class IsLoggedGuard implements CanActivate {
    constructor (private _authService: AuthService,
        private router: Router) { }


    canActivate(): Observable<boolean> | Promise<boolean> | boolean {
        if (this._authService.isLoggedIn()) {
            this.router.navigateByUrl('/');
            return false;
        } else {
            return true;
        }
    }
}
