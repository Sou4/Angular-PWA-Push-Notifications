import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { _ } from 'underscore';

@Injectable()
export class AdminAccessGuard implements CanActivate {
    constructor (private _authService: AuthService,
        private router: Router) { }


    canActivate(): Observable<boolean> | Promise<boolean> | boolean {
        if (_.indexOf(this._authService.getUserData().roles, 'admin') !== -1) {
            return true;
        } else if (_.indexOf(this._authService.getUserData().roles, 'staff') !== -1) {
            return true;
        } else {
            this.router.navigateByUrl('/');
            return false;
        }
    }
}
