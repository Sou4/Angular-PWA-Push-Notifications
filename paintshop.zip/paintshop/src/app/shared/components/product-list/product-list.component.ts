import { Component, OnInit, Input, OnChanges,  } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../../models/product';
import { CartService } from '../../services/cart.service';
import { Cart } from '../../models/cart';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { CategoryService } from '../../../product-category/services/category.service';
import { ProductService } from '../../../shared/services/product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent implements OnInit, OnChanges {
  isHandset: Observable<BreakpointState> = this.breakpointObserver.observe(Breakpoints.Handset);
  isDesktopView = true;
  @Input() selectedCategory: string;
  productCategories;
  minPrice = 0;
  maxPrice = 0;
  noProductsFound = false;
  @Input() productList: Product[];
  @Input() hideCategoryFilter = false;
  showFilter = false;
  showSort = false;
  @Input() sortType = 'Popularity';
  itemPriceFrom = 10;
  itemPriceTo = 20000;
  pageCount = 1;
  stopScrollUrl = false;
  constructor(private breakpointObserver: BreakpointObserver,
              private router: Router, private _cartServ: CartService,
              private _categoryServ: CategoryService, private _productServ: ProductService) { }

  ngOnInit() {
    this.isHandset.subscribe(res => {
      if (res.matches) {
        this.isDesktopView = false;
      } else {
        this.isDesktopView = true;
      }
    });
    console.log(this.hideCategoryFilter);
    this._categoryServ.getProductCategories()
    .subscribe(res => this.productCategories = res);
  }

  navigateToView(product) {
    this.router.navigate([`product/view/${product.id}`]);
  }

  addToCart(product: Product) {
    const cartObj: Cart = {
      id: this._cartServ.generateNextId(),
      productName: product.name,
      productId: product.id,
      productCategory: product.category,
      selectedPack: '1',
      qty: 1,
      imageUrl: product.image,
      price: product.offerprice,
      mrp: product.price,
      userId: null,
      rating: product.rating
    };
    this._cartServ.addToCart(cartObj);
  }

  categoryChanged() {
    this.stopScrollUrl = false;
    this.pageCount = 1;
    if (this.selectedCategory === undefined) {
      this._productServ.getProductsWithSort(this.sortType, this.itemPriceFrom, this.itemPriceTo, this.pageCount)
      .subscribe(res => this.productList = res);
    } else {
      this._productServ.getProductByCategoryWithSort(this.selectedCategory, this.sortType,
                              this.itemPriceFrom, this.itemPriceTo, this.pageCount)
    .subscribe(res => this.productList = res);
    }
  }

  formatLabel(value: number | null) {
    if (!value) {
      return 0;
    }

    if (value >= 1000) {
      return Math.round(value / 1000) + 'k';
    }

    return value;
  }

  onSildeFinish(itemPrice) {
    console.log('OnFinish', itemPrice);
    this.itemPriceFrom = itemPrice.from;
    this.itemPriceTo = itemPrice.to;
    this.stopScrollUrl = false;
    this.pageCount = 1;
    if (this.selectedCategory === undefined) {
      this._productServ.getProductsWithSort(this.sortType, this.itemPriceFrom, this.itemPriceTo, this.pageCount)
      .subscribe(res => {
        if ( res.length === 0) {
          this.noProductsFound = true;
        } else {
          this.noProductsFound = false;
          this.productList = res;
        }
      });
    } else {
      this._productServ.getProductByCategoryWithSort(this.selectedCategory, this.sortType,
                    this.itemPriceFrom, this.itemPriceTo, this.pageCount)
      .subscribe(res => {
        if ( res.length === 0) {
          this.noProductsFound = true;
        } else {
          this.noProductsFound = false;
          this.productList = res;
        }
      });
    }
  }

  applySort(type) {
    this.sortType = type;
    this.stopScrollUrl = false;
    this.pageCount = 1;
    if (this.selectedCategory === undefined) {
      this._productServ.getProductsWithSort(this.sortType, this.itemPriceFrom, this.itemPriceTo, this.pageCount)
      .subscribe(res => this.productList = res);
    } else {
      this._productServ.getProductByCategoryWithSort(this.selectedCategory, this.sortType,
                                  this.itemPriceFrom, this.itemPriceTo, this.pageCount)
      .subscribe(res => this.productList = res);
    }
  }

  showFilterMenu() {
    this.showFilter = true;
  }

  closeFilterMenu() {
    this.showFilter = false;
  }

  showSortMenu() {
    this.showSort = true;
  }

  closeSortMenu() {
    this.showSort = false;
  }

  ngOnChanges() {
    this.sortType = 'Popularity';
    this.stopScrollUrl = false;
    this.pageCount = 1;
    if (this.itemPriceFrom !== 10 || this.itemPriceTo !== 20000) {
      this._productServ.getProductByCategoryWithSort(this.selectedCategory, this.sortType, this.itemPriceFrom, this.itemPriceTo, 1)
      .subscribe(res => {
        if ( res.length === 0) {
          this.noProductsFound = true;
        } else {
          this.noProductsFound = false;
          this.productList = res;
        }
      });
    }
  }

  onScrollDown() {
    if (!this.stopScrollUrl) {
      console.log('prd scrolled');
      ++this.pageCount;

      if (this.selectedCategory === undefined) {
        this._productServ.getProductsWithSort(this.sortType, this.itemPriceFrom, this.itemPriceTo, this.pageCount)
        .subscribe(res => {
          if (res.length === 0) {
            this.stopScrollUrl = true;
          } else {
            res.forEach(element => {
              this.productList.push(element);
            });
          }
        });
      } else {
        this._productServ.getProductByCategoryWithSort(this.selectedCategory, this.sortType,
          this.itemPriceFrom, this.itemPriceTo, this.pageCount)
          .subscribe(res => {
            if (res.length === 0) {
              this.stopScrollUrl = true;
            } else {
              res.forEach(element => {
                this.productList.push(element);
              });
            }
          });
      }
    }
  }
}
