export class Cart {
    id: number;
    productName: string;
    productId: number;
    productCategory: string;
    selectedPack: string;
    qty: number;
    imageUrl: string;
    price: number;
    mrp: number;
    userId: number;
    rating: number;
}
