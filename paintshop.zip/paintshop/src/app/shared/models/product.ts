export class Product {
    id: number;
    name: string;
    category: string;
    description: string;
    image: string;
    otherImage: string;
    rating: number;
    price: number;
    offerprice: number;
    features: string[];
    ltrePerSqFoot: string;
    status: string;
}
