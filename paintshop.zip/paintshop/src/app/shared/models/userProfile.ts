export class UserProfile {
    id: number;
    name: string;
    username: string;
    mobile: number;
    shipAddress: string;
    pincode: number;
    cardNo: number;
    cvv: number;
    expiry: string;
    userId: number;
}
