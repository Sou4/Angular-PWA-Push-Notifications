import { Directive, HostListener, ElementRef, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective  {

  constructor(private hostElement: ElementRef,
             private renderer: Renderer2) {
    console.log('Highlight directive created');
  }

  @HostListener('click')
  onClick() {
     // console.log('Directive click');
  }

  @HostListener('mouseenter')
  onEnter() {
    // console.log('Directive mouseenter');
    this.renderer.setStyle(this.hostElement.nativeElement, 'box-shadow',
                          '0 6px 10px 0 rgba(0, 0, 0, 0.4), 0 8px 40px 0 rgba(0, 0, 0, 0.38)');
  }

  @HostListener('mouseleave')
  onLeave() {
    // console.log('Directive mouseleave');
    this.renderer.removeStyle(this.hostElement.nativeElement, 'box-shadow');
  }

}
