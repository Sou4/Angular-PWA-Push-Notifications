import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { environment } from './../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class TestimonialService {

  constructor(private http: HttpClient) {
    console.log('testimonial service created');
   }

  uploadImage(file: File): Observable<any> {
    const fd = new FormData();
    fd.append('document', file, file.name);
    return this.http.post(`${environment.apiSecuredEndPoint}/upload`, fd);
  }

  saveFeedBack(obj: any): Observable<any> {
    return this.http.post(`${environment.apiSecuredEndPoint}/api/feedbacks`, obj);
  }

  getFeedBacks(): Observable<any> {
    return this.http.get(`${environment.apiEndPoint}/api/feedbacks`);
  }

  getFeedBackByUserId(userId: any): Observable<any> {
    return this.http.get(`${environment.apiSecuredEndPoint}/api/feedbacks?userId=${userId}`);
  }

  updateFeedBack(obj: any): Observable<any> {
    return this.http.put<any>(`${environment.apiSecuredEndPoint}/api/feedbacks/${obj.id}`, obj);
  }
}
