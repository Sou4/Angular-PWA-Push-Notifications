import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { User } from '../models/user';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Cart } from '../../shared/models/cart';
import {HttpResponse} from '@angular/common/http';
import {MatSnackBar} from '@angular/material';
import { UserProfile } from '../models/userProfile';

@Injectable()
export class AuthService {
  public redirectUrl: string;
  private loggedUserName =   new BehaviorSubject('');
  loggedUserNameObsv = this.loggedUserName.asObservable();
  storage: Storage = window.localStorage;

  constructor(private http: HttpClient, private snackBar: MatSnackBar) {
    console.log('auth service created');
    if (this.isLoggedIn()) {
      if (this.storage.getItem('userData')) {
        const userData = JSON.parse(this.storage.getItem('userData'));
        this.loggedUserName.next(userData.name);
      } else {
        this.logOut();
      }
    }
  }

  authenticate(obj: User): Observable<any> {
    return this.http.post(`${environment.authEndPoint}`, obj);
  }

  registerUser(obj: User): Observable<any> {
    // this.saveUserProfile(obj);
    return this.http.post(`${environment.apiEndPoint}/api/users`, obj);
  }

  isUserRegistered(userName: string): Observable<any> {
    return this.http.get(`${environment.apiEndPoint}/api/exist/users/username/${userName}`);
  }

  getUserById(id: any): Observable<User> {
    return this.http
          .get<User>(`${environment.apiSecuredEndPoint}/api/users/${id}`);
  }

  getUserByEmail(email: any): Observable<any> {
    return this.http
          .get<any>(`${environment.apiEndPoint}/api/users?username=${email}`);
  }

  saveUserProfile(obj: UserProfile) {

    // Check whether user profile is already saved
    this.getUserProfileByUserId(obj.userId)
    .subscribe(result => {
      if (result.length === 0) {
        this.http.post(`${environment.apiEndPoint}/api/userprofile`, obj)
        .subscribe(res => {
          console.log('new user profile created');
        });
      } else {
        this.http.put(`${environment.apiEndPoint}/api/userprofile/${result[0].id}`, obj).subscribe(res => {
          console.log('user profile updated');
          this.loggedUserName.next(obj.name);
        });
      }
    });
  }

  getUserProfileByUserId(userId: any): Observable<any> {
    return this.http
          .get<any>(`${environment.apiSecuredEndPoint}/api/userprofile?userId=${userId}`);
  }

  updateUserProfile(userProfile: UserProfile) {
    this.http.put(`${environment.apiSecuredEndPoint}/api/userprofile/${userProfile.id}`, userProfile).subscribe(res => {
      console.log('user profile updated');
    });
  }

  updateUser(user: User): Observable<User> {
    return this.http.put<User>(`${environment.apiSecuredEndPoint}/api/users/${user.id}`, user);
  }

  intializeUserAfterLogIn(data: any) {
    this.storage.setItem('userData', JSON.stringify(data.identity));
    this.storage.setItem('token', data.token);
    this.loggedUserName.next(data.identity.name);
    this.snackBar.open('Logged In...', `Welcome ${data.identity.name} `, {
      duration: 2000,
    });

    // Check of Offline Cart
    // If Data available move to Web Service
    const oldCartList: Cart[] = JSON.parse(localStorage.getItem('cartList')) != null ? JSON.parse(localStorage.getItem('cartList')) : [] ;

    if (oldCartList.length > 0) {
      // Post Cart Details to Web Services
      oldCartList.forEach(cartItem => {

        // Store only unique cart objects
        this.isProductAddedToCart2(cartItem.productId, this.getUserId())
        .subscribe(isProductAddedToCart => {
          if (isProductAddedToCart.length === 0) {
            cartItem.id = null;
            cartItem.userId = data.identity.id;
            this.http.post(`${environment.apiEndPoint}/api/cart`, cartItem).subscribe();
          }
        });
      });

      // Clear all offline Cart Details
      localStorage.setItem('cartList', null);

      this.loggedUserName.next('');
      this.loggedUserName.next(data.identity.name);
    }
  }

  logOut() {
    this.storage.clear();
    this.loggedUserName.next('');
    this.redirectUrl = null;
    this.snackBar.open('Logged Out', `Thank You`, {
      duration: 2000,
    });
  }

  isLoggedIn() {
    if (this.storage.getItem('token')) {
      return true;
    } else {
      return false;
    }
  }

  getUserId(): number {
    if (this.storage.getItem('userData')) {
      const userData = JSON.parse(this.storage.getItem('userData'));
      return userData.id;
    } else {
      return 0;
    }
  }

  isProductAddedToCart(productId: number): Observable<any>  {
    return this.http.get(`${environment.apiEndPoint}/api/exist/cart/productId/${productId}`);
  }

  isProductAddedToCart2(productId: number, userId: number): Observable<any>  {
    return this.http.get(`${environment.apiEndPoint}/api/cart?productId=${productId}&userId=${userId}`);
  }

  getUserData(): User {
    const userData = JSON.parse(this.storage.getItem('userData'));
    return userData;
  }

  getAllUsers(): Observable<any> {
    return this.http
          .get<any>(`${environment.apiSecuredEndPoint}/api/users`);
  }

  updateUserFromAdmin(user: any): Observable<User> {
    return this.http.put<any>(`${environment.apiSecuredEndPoint}/api/users/${user.id}`, user);
  }

  saveUser(obj: any): Observable<any> {
    return this.http.post(`${environment.apiEndPoint}/api/users`, obj);
  }

  deleteUserById(userId: number): Observable<any> {
    return this.http.delete<any>(`${environment.apiSecuredEndPoint}/api/users/${userId}`);
  }

  addPushSubscriber(data: any): Observable<any> {
    return this.http.post(`${environment.apiEndPoint}/api/user_subscriptions`, data);
  }

  getAllSubscribers(): Observable<any> {
    return this.http.get<any>(`${environment.apiEndPoint}/api/user_subscriptions`);
  }

  sendNotifiactions(data: any): Observable<any> {
    return this.http.post(`${environment.apiSecuredEndPoint}/api/sendNotifications`, data);
  }

  getToken() {
    return this.storage.getItem('token');
  }
}
