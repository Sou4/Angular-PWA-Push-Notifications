import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import { Cart } from '../models/cart';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { _ } from 'underscore';
import { Observable } from 'rxjs/Observable';
import { AuthService } from '../services/auth.service';
import {MatSnackBar} from '@angular/material';

@Injectable()
export class CartService {
  public cartData = new BehaviorSubject<Cart[]>(null);
  cartDataObsv = this.cartData.asObservable();

  private cartCount = new BehaviorSubject<number>(0);
  currentCartCount = this.cartCount.asObservable();
  storage: Storage = window.localStorage;

   constructor(private http: HttpClient, private _authServ: AuthService,
              private snackBar: MatSnackBar) {
    console.log('cart service created');
    this.updateCartCount();
   }

   addToCart(cartObj: Cart) {
      // Check whether user logged in if yes call WEB API
      if (this.getUserId() !== 0) {
        // Store only unique cart objects
        this.isProductAddedToCart2(cartObj.productId, this.getUserId())
        .subscribe(result => {
          if (result.length === 0) {
            cartObj.id = null;
            cartObj.userId = this.getUserId();
            this.http.post(`${environment.apiEndPoint}/api/cart`, cartObj).subscribe(res => {
              this.updateCartCountObsv(this.cartCount.value + 1);
            });
          } else  {
            this.snackBar.open(`${cartObj.productName}`, 'is already added to cart', {
              duration: 2000,
            });
          }
        });

      } else {
        // Else Store in local storage
        // tslint:disable-next-line:prefer-const
        let oldCartList = JSON.parse(localStorage.getItem('cartList')) != null ? JSON.parse(localStorage.getItem('cartList')) : [] ;

        // Store only unique cart objects
        if (_.findWhere(oldCartList, {productId: cartObj.productId}) === undefined) {
          oldCartList.push(cartObj);
          localStorage.setItem('cartList', JSON.stringify(oldCartList));
          this.updateCartCountObsv(oldCartList.length);
        } else {
          this.snackBar.open(`${cartObj.productName}`, 'is already added to cart', {
            duration: 2000,
          });
        }
      }

   }

   getOfflineCartData(): Cart[] {
    const oldCartList: Cart[] = JSON.parse(localStorage.getItem('cartList')) != null ? JSON.parse(localStorage.getItem('cartList')) : [] ;
    return oldCartList;
   }

   getCartDataByUserId(userId: number): Observable<Cart[]> {
    return this.http.get<Cart[]>(`${environment.apiEndPoint}/api/cart?userId=${userId}`);
   }

   // Used to generate Next ID for new cart object
   // For only locally stored objects
   generateNextId(): number {
    const oldCartList = JSON.parse(localStorage.getItem('cartList')) != null ? JSON.parse(localStorage.getItem('cartList')) : [] ;
    return oldCartList.length + 1;
   }

   deleteCartById(cartId: number) {
     // Check whether user logged in if yes call WEB API
     if (this.getUserId() !== 0) {
        this.http.delete<Cart[]>(`${environment.apiEndPoint}/api/cart/${cartId}`)
        .subscribe(res => {
          this.updateCartCountObsv(this.cartCount.value - 1);
        });
     } else {
        // Else Store in local storage
        // tslint:disable-next-line:prefer-const
        let oldCartList = JSON.parse(localStorage.getItem('cartList')) != null ? JSON.parse(localStorage.getItem('cartList')) : [] ;
        oldCartList = _.difference(oldCartList, _.where(oldCartList, {id: cartId}));
        localStorage.setItem('cartList', JSON.stringify(oldCartList));
        this.updateCartCountObsv(oldCartList.length);
     }
   }

   updateCart(cartObj: Cart) {
    // Check whether user logged in if yes call WEB API
    if (this.getUserId() !== 0) {
      this.http.put(`${environment.apiEndPoint}/api/cart/${cartObj.id}`, cartObj).subscribe(res => {
        console.log('updated');
      });
    } else {
      // Else Store in local storage
      // tslint:disable-next-line:prefer-const
      let oldCartList = JSON.parse(localStorage.getItem('cartList')) != null ? JSON.parse(localStorage.getItem('cartList')) : [] ;
      oldCartList = _.difference(oldCartList, _.where(oldCartList, {id: cartObj.id}));
      oldCartList.push(cartObj);
      localStorage.setItem('cartList', JSON.stringify(oldCartList));
      // this.updateCartCountObsv(oldCartList.length);
    }
   }

   updateCartCountObsv(count: number) {
    this.cartCount.next(count);
   }

   updateCartCount() {
    if (this._authServ.isLoggedIn()) {
      this.getCartDataByUserId(this._authServ.getUserId())
      .subscribe(res => {
        this.updateCartCountObsv(res.length);
      });
    } else {
      const oldCartList = JSON.parse(localStorage.getItem('cartList')) != null ? JSON.parse(localStorage.getItem('cartList')) : [] ;
      this.updateCartCountObsv(oldCartList.length);
    }
   }

   getUserId(): number {
    if (this.storage.getItem('userData')) {
      const userData = JSON.parse(this.storage.getItem('userData'));
      return userData.id;
    } else {
      return 0; // Not Logged In
    }
  }

  isProductAddedToCart(productId: number): Observable<any>  {
    return this.http.get(`${environment.apiEndPoint}/api/exist/cart/productId/${productId}`);
  }

  isProductAddedToCart2(productId: number, userId: number): Observable<any>  {
    return this.http.get(`${environment.apiEndPoint}/api/cart?productId=${productId}&userId=${userId}`);
  }

}
