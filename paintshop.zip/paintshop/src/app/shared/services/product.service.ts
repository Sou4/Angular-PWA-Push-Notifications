import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { environment } from './../../../environments/environment';
import { Product } from '../models/product';

@Injectable()
export class ProductService {

  constructor(private http: HttpClient) {
    console.log('product service created');
   }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product?status=active`);
  }

  getProductById(id: any): Observable<Product> {
    return this.http
          .get<Product>(`${environment.apiEndPoint}/api/product/${id}`);
  }

  getProductByCategory(category: any): Observable<Product[]> {
    return this.http
          .get<Product[]>(`${environment.apiEndPoint}/api/product?category=${category}&status=active`);
  }

  getProductWithInPriceRange(minPrice: any, maxPrice: any): Observable<Product[]> {
    return this.http
          .get<Product[]>(`${environment.apiEndPoint}/api/product?offerprice_gte=${minPrice}&offerprice_lte=${maxPrice}&status=active`);
  }

  // For Filters
  getProductsWithSort(sortType: string, minPrice: any, maxPrice: any, pageNo: number): Observable<Product[]> {
    if (sortType === 'Popularity') {
      // tslint:disable-next-line:max-line-length
      return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product?status=active&offerprice_gte=${minPrice}&offerprice_lte=${maxPrice}&_sort=rating&_order=desc&_page=${pageNo}&_limit=3`);
    } else if ( sortType === 'Price Low to High' ) {
      // tslint:disable-next-line:max-line-length
      return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product?status=active&offerprice_gte=${minPrice}&offerprice_lte=${maxPrice}&_sort=offerprice&_order=asc&_page=${pageNo}&_limit=3`);
    } else if ( sortType === 'Price High to Low' ) {
      // tslint:disable-next-line:max-line-length
      return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product?status=active&offerprice_gte=${minPrice}&offerprice_lte=${maxPrice}&_sort=offerprice&_order=desc&_page=${pageNo}&_limit=3`);
    }
  }

  getProductByCategoryWithSort(category: any, sortType: string, minPrice: any, maxPrice: any, pageNo: any): Observable<Product[]> {
    if (sortType === 'Popularity') {
      // tslint:disable-next-line:max-line-length
      return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product?status=active&category=${category}&offerprice_gte=${minPrice}&offerprice_lte=${maxPrice}&_sort=rating&_order=desc&_page=${pageNo}&_limit=3`);
    } else if ( sortType === 'Price Low to High' ) {
      // tslint:disable-next-line:max-line-length
      return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product?status=active&category=${category}&offerprice_gte=${minPrice}&offerprice_lte=${maxPrice}&_sort=offerprice&_order=asc&_page=${pageNo}&_limit=3`);
    } else if ( sortType === 'Price High to Low' ) {
      // tslint:disable-next-line:max-line-length
      return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product?status=active&category=${category}&offerprice_gte=${minPrice}&offerprice_lte=${maxPrice}&_sort=offerprice&_order=desc&_page=${pageNo}&_limit=3`);    }
  }

  updateProduct(product: Product): Observable<any> {
    // Check whether user logged in if yes call WEB API
    return this.http.put<Product>(`${environment.apiSecuredEndPoint}/api/product/${product.id}`, product);
  }

  deleteProductById(productId: number): Observable<any> {
    return this.http.delete<Product>(`${environment.apiSecuredEndPoint}/api/product/${productId}`);
  }

  addProduct(product: Product): Observable<any> {
    return this.http.post<Product>(`${environment.apiSecuredEndPoint}/api/product`, product);
  }

  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product`);
  }

  searchProducts(searchText: string): Observable<Product[]> {
    return this.http.get<Product[]>(`${environment.apiEndPoint}/api/product?q=${searchText}`);
  }
}
