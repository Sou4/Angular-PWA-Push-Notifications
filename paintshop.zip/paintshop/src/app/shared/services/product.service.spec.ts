import { TestBed, inject } from '@angular/core/testing';
import { Product } from '../models/product';
import { ProductService } from './product.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('ProductService', () => {
  let productService: ProductService;
  let httpMock: HttpTestingController;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ProductService]
    });
    productService = TestBed.get(ProductService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('should be created', inject([ProductService], (service: ProductService) => {
    expect(service).toBeTruthy();
  }));

  it('should get products', (done) => {

    productService.getProducts()
                  .subscribe ( products => {
                    expect(products.length).toBe(2);
                    expect(products).toEqual(<Product[]> [
                      { id: 1, name: '24 Carat'},
                      { id: 2, name: 'EXCEL RAIN GUARD'}
                    ]);
                    done();
                  });


    const productsRequest = httpMock.expectOne('http://localhost:7070/delayed/api/product?status=active');
    // respond with json data
    productsRequest.flush([{id: 1, name: '24 Carat'}, {id: 2, name: 'EXCEL RAIN GUARD'}]);

    httpMock.verify();
  });

  it('should get one product', (done) => {

    productService.getProductById(10)
                  .subscribe ( product => {
                    expect(product.id).toBe(10);
                    done();
                  });

    const productsRequest = httpMock.expectOne('http://localhost:7070/delayed/api/product/10');
    productsRequest.flush({id: 10});

    httpMock.verify();
  });

  it('should get products by category', (done) => {

    productService.getProductByCategory('InteriorWallPaints')
                  .subscribe ( products => {
                    expect(products.length).toBe(1);
                    expect(products).toEqual(<Product[]> [
                      { id: 1, name: '24 Carat', category: 'InteriorWallPaints'}
                    ]);
                    done();
                  });

    const productsRequest =
      httpMock.expectOne('http://localhost:7070/delayed/api/product?category=InteriorWallPaints&status=active');
    productsRequest.flush([{id: 1, name: '24 Carat', category: 'InteriorWallPaints'}]);

    httpMock.verify();
  });
});
