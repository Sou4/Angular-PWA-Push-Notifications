import { Cart } from '../../shared/models/cart';

export class Order {
    id: number;
    userId: number;
    name: string;
    email: string;
    mobile: number;
    cardNo: number;
    totalAmount: number;
    delivaryCharges: number;
    amountPaid: number;
    savings: number;
    shipAddress: string;
    products: Cart[];
    pincode: number;
    invoiceDate: string;
}
