import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlaceOrderComponent } from './components/place-order/place-order.component';
import { Routes, RouterModule } from '@angular/router';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatCardModule, MatButtonModule, MatIconModule, MatListModule,
  MatSelectModule, MatFormFieldModule, MatInputModule, MatExpansionModule, MatSnackBarModule } from '@angular/material';
import { FormsModule } from '@angular/forms';
import { OrderService } from './services/order.service';
import { ConfirmationComponent } from './components/confirmation/confirmation.component';
import { InvoiceComponent } from './components/invoice/invoice.component';
import { OnPageLeaveGuard } from './guards/page-leave-guard';

const routes: Routes = [
  {
    path: 'placeOrder',
    component: PlaceOrderComponent,
    canDeactivate: [OnPageLeaveGuard]
  },
  {
    path: 'confirmSheet/:id',
    component: ConfirmationComponent
  },
  {
    path: 'invoice/:id',
    component: InvoiceComponent
  }
];

@NgModule({
  imports: [
    CommonModule,
    FlexLayoutModule,
    RouterModule.forChild(routes),
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    MatExpansionModule,
    FormsModule,
    MatSnackBarModule
  ],
  declarations: [PlaceOrderComponent, ConfirmationComponent, InvoiceComponent],
  providers: [
    OrderService,
    OnPageLeaveGuard
  ]
})
export class OrderModule { }
