import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Order } from '../../models/order';
import { OrderService } from '../../services/order.service';
import { CartService } from '../../../shared/services/cart.service';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent implements OnInit {
  order: Order;
  constructor(private route: ActivatedRoute, private _orderServ: OrderService,
              private _cartServ: CartService) { }

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      this._orderServ.getOrderById(params.id)
      .subscribe(res => {
        if (res !== null) {
          this.order = res;
          this.order.products.forEach(
            item => this._cartServ.deleteCartById(item.id)
          );
        }
      });
   });
  }

}
