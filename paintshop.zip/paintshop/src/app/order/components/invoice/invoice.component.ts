import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { Order } from '../../models/order';
import { OrderService } from '../../services/order.service';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
  order: Order;
  constructor(private route: ActivatedRoute, private _orderServ: OrderService,
              private router: Router) { }

  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      this._orderServ.getOrderById(params.id)
      .subscribe(res => {
        this.order = res;
      });
   });
  }

  navigateToView(cart) {
    this.router.navigate([`product/view/${cart.productId}`]);
  }

  printInvoice() {
    window.print();
  }
}
