import { Component, OnInit, OnDestroy } from '@angular/core';
import { CartService } from '../../../shared/services/cart.service';
import { Cart } from '../../../shared/models/cart';
import { AuthService } from '../../../shared/services/auth.service';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material';
import { Order } from '../../models/order';
import { OrderService } from '../../services/order.service';
import { Router } from '@angular/router';
import { User } from '../../../shared/models/user';
import { UserProfile } from '../../../shared/models/userProfile';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit, OnDestroy {
  step = 0;
  cartList: Cart[];
  totalAmount = 0;
  totalMrp = 0;
  totalItems = 0;
  confirmOrder = false;
  // Form Variables
  name;
  email;
  mobileNo;
  address;
  cardNo;
  cvv;
  expiry;
  pincode;

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }

  constructor(private _cartServ: CartService, private _authServ: AuthService,
              private snackBar: MatSnackBar, private _orderServ: OrderService,
              private router: Router) { }

  ngOnInit() {
    this._cartServ.cartDataObsv
    .subscribe(res => {
      if (res !== null) {
        this.cartList = res;
        this.calculateTotalAmount();
      }
    });

   this.email = this._authServ.getUserData().username;

   this._authServ.getUserProfileByUserId(this._authServ.getUserId())
   .subscribe(res => {
      if ( res.length !== 0 ) {
        this.mobileNo = res[0].mobile;
        this.address = res[0].shipAddress;
        this.cardNo = res[0].cardNo;
        this.cvv = res[0].cvv;
        this.expiry = res[0].expiry;
        this.pincode = res[0].pincode;
        this.name =  res[0].name;
      } else {
        this.name = this._authServ.getUserData().name;
      }
   });
  }

  ngOnDestroy() {
    this._cartServ.cartData.next(null);
  }

  calculateTotalAmount() {
    this.totalAmount = 0;
    this.totalMrp = 0;
    this.totalItems = 0;
    this.cartList.forEach(item => {
      this.totalAmount += (item.price * parseFloat(item.selectedPack) * item.qty);
      this.totalMrp += (item.mrp * parseFloat(item.selectedPack) * item.qty);
      this.totalItems += 1;
    });
  }

  checkOut() {
    if (this.name === '' || this.name === undefined) {
      this.snackBar.open('Please Enter Name' , 'Alert', {
        duration: 4000
      });
    } else if (this.email === '' || this.email === undefined) {
      this.snackBar.open('Please Enter Email' , 'Alert', {
        duration: 4000
      });
    } else if (this.mobileNo === '' || this.mobileNo === undefined) {
      this.snackBar.open('Please Enter Mobile' , 'Alert', {
        duration: 4000
      });
    } else if (this.address === '' || this.address === undefined) {
      this.snackBar.open('Please Enter Address' , 'Alert', {
        duration: 4000
      });
    } else if (this.cardNo === '' || this.cardNo === undefined) {
      this.snackBar.open('Please Enter Card Number' , 'Alert', {
        duration: 4000
      });
    } else if (this.cvv === '' || this.cvv === undefined) {
      this.snackBar.open('Please Enter CVV' , 'Alert', {
        duration: 4000
      });
    } else if (this.expiry === '' || this.expiry === undefined) {
      this.snackBar.open('Please Enter Expiry' , 'Alert', {
        duration: 4000
      });
    } else if (this.pincode === '' || this.pincode === undefined) {
      this.snackBar.open('Please Enter Pincode' , 'Alert', {
        duration: 4000
      });
    } else {
      const order: Order = {
        id: null,
        userId: this._authServ.getUserData().id,
        name: this.name,
        email: this.email,
        mobile: this.mobileNo,
        cardNo: this.cardNo,
        totalAmount: this.totalAmount,
        delivaryCharges: 0,
        amountPaid: this.totalAmount,
        savings: this.totalMrp - this.totalAmount,
        shipAddress: this.address,
        products: this.cartList,
        pincode: this.pincode,
        invoiceDate: '' + new Date()
      };

      console.log(order);

      this._orderServ.saveOrder(order)
      .subscribe(res => {
        // Update User Data
        const userData: User = this._authServ.getUserData();

        const userProfile: UserProfile = {
          id: null,
          name: this.name,
          username: userData.username,
          mobile: this.mobileNo,
          shipAddress: this.address,
          pincode: this.pincode,
          cardNo: this.cardNo,
          cvv: this.cvv,
          expiry: this.expiry,
          userId: userData.id
        };

        this._authServ.saveUserProfile(userProfile);
        this.confirmOrder = true;
        this.router.navigate([`/order/confirmSheet/${res.id}`]);
      });
    }
  }

  canDeactivate() {
    if (!this.confirmOrder) {
      if (window.confirm('Do you want leave the page ?')) {
        return true;
      } else {
        return false;
      }
    } else {
      return true;
    }
  }
}
