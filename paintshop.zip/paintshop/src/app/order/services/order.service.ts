import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Order } from '../models/order';

@Injectable()
export class OrderService {

  constructor(private http: HttpClient) { }

  saveOrder(obj: Order): Observable<any> {
    return this.http.post(`${environment.apiSecuredEndPoint}/api/orders`, obj);
  }

  getOrderById(id: number): Observable<Order> {
    return this.http
          .get<Order>(`${environment.apiSecuredEndPoint}/api/orders/${id}`);
  }

  getAllOrdersByUserId(userId: number): Observable<Order[]> {
    return this.http
          .get<Order[]>(`${environment.apiSecuredEndPoint}/api/orders?userId=${userId}`);
  }

  getAllOrders(): Observable<Order[]> {
    return this.http
          .get<Order[]>(`${environment.apiSecuredEndPoint}/api/orders`);
  }
}
